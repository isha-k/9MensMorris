package Frontend.Button;

import Frontend.GameUI;

/**
 * Restart button restarts the entire game.
 */
public class ButtonRestart extends ButtonAbstract {

    /**
     * Constructs a new ButtonRestart instance.
     * It creates a button with the label "Restart".
     */
    public ButtonRestart() {
        super("Restart");
    }

    /**
     * Event listener for the button.
     * It creates a new instance of the GameUI, effectively restarting the game.
     */
    public void eventListener() {
        new GameUI();
    }

}
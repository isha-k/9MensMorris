package Frontend.Button;

import Frontend.GameUI;

public class ButtonCustomise extends ButtonAbstract {

    /**
     * Constructs a new ButtonCustomise instance.
     * It creates a button labeled "Customise".
     */
    public ButtonCustomise() {
        super("Start Game");
    }

    /**
     * Event listener for the button.
     * It performs actions when the button is clicked, including switching to the "Customise Panel" layout
     * and setting the game running status to false.
     */
    public void eventListener() {
        GameUI.layout.show(GameUI.homeContainer, "Customise Panel");
        GameUI.gameEngine.setGameRunningStatus(false);
    }

}
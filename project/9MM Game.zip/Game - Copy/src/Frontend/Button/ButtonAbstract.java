package Frontend.Button;

import javax.swing.*;

/**
 * An abstract class to specify the behaviour and state of buttons in the Game UI.
 */
public abstract class ButtonAbstract extends JButton {

    /**
     * Constructs a new ButtonAbstract instance with the specified text.
     *
     * @param text The text displayed on the button.
     */
    public ButtonAbstract(String text) {
        super(text);
        this.addActionListener(e -> {
            try {
                eventListener();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    /** Implementation of how the application should respond in response to the button being clicked */
    public abstract void eventListener() throws Exception;

}

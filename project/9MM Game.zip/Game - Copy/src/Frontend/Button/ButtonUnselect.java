package Frontend.Button;

import Frontend.GameUI;

/**
 * Unselect button undos a players decision.
 */
public class ButtonUnselect extends ButtonAbstract {

    /**
     * Constructs a new ButtonUnselect instance.
     * It creates a button with the label "Unselect".
     */
    public ButtonUnselect() {
        super("Unselect");
    }

    /**
     * Event listener for the button.
     * It calls the `unselectPosition()` method in the GameEngine to unselect a position.
     */
    public void eventListener() {
        GameUI.gameEngine.unselectPosition();
    }

}
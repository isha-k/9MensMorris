package Frontend.Button;

import Frontend.GameUI;

/**
 * Back button restarts game and returns users to the home page.
 */
public class ButtonBack extends ButtonAbstract {

    /**
     * Constructs a new ButtonBack instance.
     * It creates a button labeled "Back".
     */
    public ButtonBack() {
        super("Back");
    }

    /**
     * Event listener for the button.
     * It performs actions when the button is clicked, including switching to the "Home" layout
     * and setting the game running status to false.
     */
    public void eventListener() {
        GameUI.layout.show(GameUI.homeContainer, "Game Home");
        GameUI.gameEngine.setGameRunningStatus(false);
    }

}
package Frontend.Button;

import Backend.GameEngine;
import Frontend.GameUI;
import Frontend.Grids.GridCustomise;
import Frontend.Grids.GridMarker;
import Frontend.Screen.ScreenCustomise;

import javax.swing.*;

/**
 * The ButtonStart class represents a start button in the screen customizer.
 * Clicking the button initiates the game with the selected customizations.
 */
public class ButtonStart extends ButtonAbstract {

    private GridCustomise panelGrid;
    private ScreenCustomise screenCustomise;

    /**
     * Constructs a ButtonStart object with the specified ScreenCustomise and GridCustomise instances.
     * @param screenCustomise The ScreenCustomise instance associated with the button.
     * @param gridCustomise   The GridCustomise instance associated with the button.
     */
    public ButtonStart(ScreenCustomise screenCustomise, GridCustomise gridCustomise) {
        super("Start");
        this.screenCustomise = screenCustomise;
        this.panelGrid = gridCustomise;
    }

    /**
     * Overrides the eventListener method from the ButtonAbstract class.
     * Performs the necessary actions when the button is clicked.
     */
    @Override
    public void eventListener() {
        int gridSize = Math.max(this.panelGrid.gridWidth, this.panelGrid.gridHeight);
        try {
            int playerCount = Integer.parseInt(this.screenCustomise.getAdjusterCustomisePlayer().getFieldPlayerCount());
            int markerCount = Integer.parseInt(this.screenCustomise.getAdjusterCustomisePlayer().getFieldMarkerCount());
            if (playerCount < 2) {
                JOptionPane.showMessageDialog(this, "Error. Player count must be at least 2!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (markerCount < 3) {
                JOptionPane.showMessageDialog(this, "Error. Marker count must be at least 3!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                GridMarker.getInstance().initialiseGrid(markerCount, playerCount);
                GameEngine.getInstance().initialiseGame(gridSize, markerCount, playerCount, panelGrid.translateToPositions());
                GameUI.layout.show(GameUI.homeContainer, "Game Panel");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error. Invaid input!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
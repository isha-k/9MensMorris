package Frontend.Screen;

import Frontend.Adjusters.AdjusterCustomiseGrid;
import Frontend.Adjusters.AdjusterCustomisePlayer;
import Frontend.Observer;
import Frontend.Grids.Grid;
import Frontend.Grids.GridCustomise;
import Frontend.Panels.PanelControl;
import Frontend.Panels.PanelFooter;

import javax.swing.*;
import java.awt.*;

/**
 * The ScreenCustomise class represents a panel where users can customize the game board.
 * It allows users to draw nodes and edges for the game board layout.
 */
public class ScreenCustomise extends JPanel implements Observer {

    /**
     * The panel that contains the grid for drawing nodes and edges.
     */
    private GridCustomise gridCustomise;
    private PanelControl panelControl;
    private AdjusterCustomisePlayer adjusterCustomisePlayer;

    /**
     * Constructs a new ScreenCustomise object.
     */
    public ScreenCustomise() {
        super();
        setLayout(new BorderLayout());

        this.gridCustomise = GridCustomise.getInstance();
        this.panelControl = new PanelControl(gridCustomise, this);
        add(panelControl, BorderLayout.NORTH);

        JPanel panelGridContainer = new JPanel(new BorderLayout());
        panelGridContainer.add(gridCustomise, BorderLayout.CENTER);

        JPanel panelGridAdjuster = new JPanel(new BorderLayout());
        JPanel innerPanelGridAdjuster = new JPanel();
        innerPanelGridAdjuster.setLayout(new BoxLayout(innerPanelGridAdjuster, BoxLayout.Y_AXIS));
        this.adjusterCustomisePlayer = new AdjusterCustomisePlayer();
        innerPanelGridAdjuster.add(this.adjusterCustomisePlayer);
        innerPanelGridAdjuster.add(Box.createVerticalStrut(8)); // Add spacing between components
        innerPanelGridAdjuster.add(new AdjusterCustomiseGrid(this));

        panelGridAdjuster.add(innerPanelGridAdjuster, BorderLayout.NORTH);

        JPanel combinedPanel = new JPanel(new FlowLayout());
        combinedPanel.add(panelGridContainer);
        combinedPanel.add(panelGridAdjuster);

        add(combinedPanel, BorderLayout.CENTER);

        add(new PanelFooter(gridCustomise), BorderLayout.SOUTH);

        this.board9mm();
    }

    /**
     * Retrieves the adjusterCustomisePlayer object.
     *
     * @return the adjusterCustomisePlayer object
     */
    public AdjusterCustomisePlayer getAdjusterCustomisePlayer() {
        return adjusterCustomisePlayer;
    }

    /**
     * Resets the gridCustomise.
     */
    public void reset() {
        this.gridCustomise.modifyGrid();
    }

    /**
     * Sets up the gridCustomise for a 3mm game board.
     */
    public void board3mm() {
        Grid.changeGridSize(3,3);
        this.gridCustomise.modifyGrid();
        this.gridCustomise.addPosition(0,null);
        this.gridCustomise.addPosition(1, null);
        this.gridCustomise.addPosition(2, null);
        this.gridCustomise.addPosition(3, null);
        this.gridCustomise.addPosition(4, null);
        this.gridCustomise.addPosition(5, null);
        this.gridCustomise.addPosition(6, null);
        this.gridCustomise.addPosition(7, null);
        this.gridCustomise.addPosition(8, null);
        this.gridCustomise.addNeighbour(8, 4);
        this.gridCustomise.addNeighbour(8, 7);
        this.gridCustomise.addNeighbour(6, 7);
        this.gridCustomise.addNeighbour(7, 4);
        this.gridCustomise.addNeighbour(6, 4);
        this.gridCustomise.addNeighbour(6, 3);
        this.gridCustomise.addNeighbour(3, 4);
        this.gridCustomise.addNeighbour(5, 4);
        this.gridCustomise.addNeighbour(8, 5);
        this.gridCustomise.addNeighbour(5, 2);
        this.gridCustomise.addNeighbour(4, 2);
        this.gridCustomise.addNeighbour(4, 1);
        this.gridCustomise.addNeighbour(2, 1);
        this.gridCustomise.addNeighbour(3, 0);
        this.gridCustomise.addNeighbour(0, 1);
        this.gridCustomise.addNeighbour(0, 4);
        this.adjusterCustomisePlayer.setFieldPlayerCount("2");
        this.adjusterCustomisePlayer.setFieldMarkerCount("3");
        this.gridCustomise.repaint();
    }

    /**
     * Sets up the gridCustomise for a 6mm game board.
     */
    public void board6mm() {
        Grid.changeGridSize(5,5);
        this.gridCustomise.modifyGrid();
        this.gridCustomise.addPosition(0, null);
        this.gridCustomise.addPosition(2, null);
        this.gridCustomise.addPosition(4, null);
        this.gridCustomise.addPosition(6, null);
        this.gridCustomise.addPosition(7, null);
        this.gridCustomise.addPosition(8, null);
        this.gridCustomise.addPosition(10, null);
        this.gridCustomise.addPosition(11, null);
        this.gridCustomise.addPosition(13, null);
        this.gridCustomise.addPosition(14, null);
        this.gridCustomise.addPosition(16, null);
        this.gridCustomise.addPosition(17, null);
        this.gridCustomise.addPosition(18, null);
        this.gridCustomise.addPosition(20, null);
        this.gridCustomise.addPosition(22, null);
        this.gridCustomise.addPosition(24, null);
        this.gridCustomise.addNeighbour(0, 2);
        this.gridCustomise.addNeighbour(0, 10);
        this.gridCustomise.addNeighbour(2, 4);
        this.gridCustomise.addNeighbour(2, 7);
        this.gridCustomise.addNeighbour(4, 14);
        this.gridCustomise.addNeighbour(6, 7);
        this.gridCustomise.addNeighbour(6, 11);
        this.gridCustomise.addNeighbour(7, 8);
        this.gridCustomise.addNeighbour(8, 13);
        this.gridCustomise.addNeighbour(10, 11);
        this.gridCustomise.addNeighbour(10, 20);
        this.gridCustomise.addNeighbour(11, 16);
        this.gridCustomise.addNeighbour(13, 14);
        this.gridCustomise.addNeighbour(13, 18);
        this.gridCustomise.addNeighbour(14, 24);
        this.gridCustomise.addNeighbour(16, 17);
        this.gridCustomise.addNeighbour(17, 18);
        this.gridCustomise.addNeighbour(17, 22);
        this.gridCustomise.addNeighbour(20, 22);
        this.gridCustomise.addNeighbour(22, 24);
        this.adjusterCustomisePlayer.setFieldPlayerCount("2");
        this.adjusterCustomisePlayer.setFieldMarkerCount("6");
        this.gridCustomise.repaint();
    }

    /**
     * Sets up the gridCustomise for a 9mm game board.
     */
    public void board9mm() {
        Grid.changeGridSize(7,7);
        this.gridCustomise.modifyGrid();
        this.gridCustomise.addPosition(0,null);
        this.gridCustomise.addPosition(3,null);
        this.gridCustomise.addPosition(6,null);
        this.gridCustomise.addPosition(8,null);
        this.gridCustomise.addPosition(10,null);
        this.gridCustomise.addPosition(12,null);
        this.gridCustomise.addPosition(16,null);
        this.gridCustomise.addPosition(17,null);
        this.gridCustomise.addPosition(18,null);
        this.gridCustomise.addPosition(21,null);
        this.gridCustomise.addPosition(22,null);
        this.gridCustomise.addPosition(23,null);
        this.gridCustomise.addPosition(25,null);
        this.gridCustomise.addPosition(26,null);
        this.gridCustomise.addPosition(27,null);
        this.gridCustomise.addPosition(30,null);
        this.gridCustomise.addPosition(31,null);
        this.gridCustomise.addPosition(32,null);
        this.gridCustomise.addPosition(36,null);
        this.gridCustomise.addPosition(38,null);
        this.gridCustomise.addPosition(40,null);
        this.gridCustomise.addPosition(42,null);
        this.gridCustomise.addPosition(45,null);
        this.gridCustomise.addPosition(48,null);
        this.gridCustomise.addNeighbour(0, 3);
        this.gridCustomise.addNeighbour(0, 21);
        this.gridCustomise.addNeighbour(3, 6);
        this.gridCustomise.addNeighbour(3, 10);
        this.gridCustomise.addNeighbour(6, 27);
        this.gridCustomise.addNeighbour(8, 10);
        this.gridCustomise.addNeighbour(8, 22);
        this.gridCustomise.addNeighbour(10, 12);
        this.gridCustomise.addNeighbour(10, 17);
        this.gridCustomise.addNeighbour(12, 26);
        this.gridCustomise.addNeighbour(16, 17);
        this.gridCustomise.addNeighbour(16, 23);
        this.gridCustomise.addNeighbour(17, 18);
        this.gridCustomise.addNeighbour(18, 25);
        this.gridCustomise.addNeighbour(21, 22);
        this.gridCustomise.addNeighbour(21, 42);
        this.gridCustomise.addNeighbour(22, 23);
        this.gridCustomise.addNeighbour(22, 36);
        this.gridCustomise.addNeighbour(23, 30);
        this.gridCustomise.addNeighbour(25, 26);
        this.gridCustomise.addNeighbour(25, 32);
        this.gridCustomise.addNeighbour(26, 27);
        this.gridCustomise.addNeighbour(26, 40);
        this.gridCustomise.addNeighbour(27, 48);
        this.gridCustomise.addNeighbour(30, 31);
        this.gridCustomise.addNeighbour(31, 32);
        this.gridCustomise.addNeighbour(31, 38);
        this.gridCustomise.addNeighbour(36, 38);
        this.gridCustomise.addNeighbour(38, 40);
        this.gridCustomise.addNeighbour(38, 45);
        this.gridCustomise.addNeighbour(42, 45);
        this.gridCustomise.addNeighbour(45, 48);
        this.adjusterCustomisePlayer.setFieldPlayerCount("2");
        this.adjusterCustomisePlayer.setFieldMarkerCount("9");
        this.gridCustomise.repaint();
    }

    /**
     * Sets up the gridCustomise for a 12mm game board.
     */
    public void board12mm() {
        Grid.changeGridSize(7,7);
        this.gridCustomise.modifyGrid();
        this.gridCustomise.addPosition(0, null);
        this.gridCustomise.addPosition(3, null);
        this.gridCustomise.addPosition(6, null);
        this.gridCustomise.addPosition(8, null);
        this.gridCustomise.addPosition(10, null);
        this.gridCustomise.addPosition(12, null);
        this.gridCustomise.addPosition(16, null);
        this.gridCustomise.addPosition(17, null);
        this.gridCustomise.addPosition(18, null);
        this.gridCustomise.addPosition(21, null);
        this.gridCustomise.addPosition(22, null);
        this.gridCustomise.addPosition(23, null);
        this.gridCustomise.addPosition(25, null);
        this.gridCustomise.addPosition(26, null);
        this.gridCustomise.addPosition(27, null);
        this.gridCustomise.addPosition(30, null);
        this.gridCustomise.addPosition(31, null);
        this.gridCustomise.addPosition(32, null);
        this.gridCustomise.addPosition(36, null);
        this.gridCustomise.addPosition(38, null);
        this.gridCustomise.addPosition(40, null);
        this.gridCustomise.addPosition(42, null);
        this.gridCustomise.addPosition(45, null);
        this.gridCustomise.addPosition(48, null);
        this.gridCustomise.addNeighbour(0, 3);
        this.gridCustomise.addNeighbour(0, 8);
        this.gridCustomise.addNeighbour(0, 21);
        this.gridCustomise.addNeighbour(3, 6);
        this.gridCustomise.addNeighbour(3, 10);
        this.gridCustomise.addNeighbour(6, 12);
        this.gridCustomise.addNeighbour(6, 27);
        this.gridCustomise.addNeighbour(8, 10);
        this.gridCustomise.addNeighbour(8, 16);
        this.gridCustomise.addNeighbour(8, 22);
        this.gridCustomise.addNeighbour(10, 12);
        this.gridCustomise.addNeighbour(10, 17);
        this.gridCustomise.addNeighbour(12, 26);
        this.gridCustomise.addNeighbour(12, 18);
        this.gridCustomise.addNeighbour(16, 17);
        this.gridCustomise.addNeighbour(16, 23);
        this.gridCustomise.addNeighbour(17, 18);
        this.gridCustomise.addNeighbour(18, 25);
        this.gridCustomise.addNeighbour(21, 22);
        this.gridCustomise.addNeighbour(21, 42);
        this.gridCustomise.addNeighbour(22, 23);
        this.gridCustomise.addNeighbour(22, 36);
        this.gridCustomise.addNeighbour(23, 30);
        this.gridCustomise.addNeighbour(25, 26);
        this.gridCustomise.addNeighbour(25, 32);
        this.gridCustomise.addNeighbour(26, 27);
        this.gridCustomise.addNeighbour(26, 40);
        this.gridCustomise.addNeighbour(27, 48);
        this.gridCustomise.addNeighbour(30, 31);
        this.gridCustomise.addNeighbour(30, 36);
        this.gridCustomise.addNeighbour(31, 32);
        this.gridCustomise.addNeighbour(31, 38);
        this.gridCustomise.addNeighbour(32, 40);
        this.gridCustomise.addNeighbour(36, 38);
        this.gridCustomise.addNeighbour(36, 42);
        this.gridCustomise.addNeighbour(38, 40);
        this.gridCustomise.addNeighbour(38, 45);
        this.gridCustomise.addNeighbour(40, 48);
        this.gridCustomise.addNeighbour(42, 45);
        this.gridCustomise.addNeighbour(45, 48);
        this.adjusterCustomisePlayer.setFieldPlayerCount("2");
        this.adjusterCustomisePlayer.setFieldMarkerCount("12");
        this.gridCustomise.repaint();
    }

    /**
     * Updates the ScreenCustomise panel when notified of changes in the grid.
     */
    @Override
    public void update() {}

}





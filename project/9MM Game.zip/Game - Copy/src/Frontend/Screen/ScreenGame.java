package Frontend.Screen;

import Backend.Action.Action;
import Backend.GameEngine;
import Frontend.Adjusters.AdjusterCustomiseGrid;
import Frontend.Adjusters.AdjusterCustomisePlayer;
import Frontend.Button.ButtonAbstract;
import Frontend.Button.ButtonRestart;
import Frontend.Button.ButtonUnselect;
import Frontend.Grids.GridCustomise;
import Frontend.Grids.GridGame;
import Frontend.Grids.GridMarker;
import Frontend.Observer;
import Frontend.Panels.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * The Screen for the user to visualize and play the game
 */
public class ScreenGame extends JComponent implements Observer {

    private GameEngine gameEngine;
    private GridGame gridGame;
    private GridMarker markers;
    private PanelTurn scorePanel;

    public static ButtonAbstract unselectButton;


    /**
     * Constructs a new GraphPanel object with the specified game engine.
     *
     */
    public ScreenGame() {

        this.setOpaque(true); // Set opaque
        this.gameEngine = GameEngine.getInstance(); // Set gameEngine instance
        this.gameEngine.attach(this);// Add current class and mouse handler as observers of changes to gameEngine instance
        setLayout(new BorderLayout());
        this.add(new ButtonRestart(), BorderLayout.NORTH);
        JPanel gameContainer = new JPanel(new FlowLayout());
        this.gridGame = GridGame.getInstance();
        gameContainer.add(gridGame);
        this.scorePanel = new PanelTurn();
        gameContainer.add(scorePanel);
        this.markers = GridMarker.getInstance();
        gameContainer.add(markers);
        this.add(gameContainer, BorderLayout.CENTER);
        this.unselectButton = new ButtonUnselect();
        this.add(unselectButton,BorderLayout.SOUTH);

    }

    /**
     * Draws the game graphically by creating and adding the visual elements to the collection.
     */
    public void synchroniseWithGame(){
        Map<Integer, List<Action>> gameActions = GameEngine.getInstance().getNextActions();
        this.gridGame.modifyGrid();
        this.markers.modifyGrid();
        for (int index : gameActions.keySet()) {
            if (GameEngine.getInstance().playerSelectedMarkerActionMarker()) {
                gameActions.get(GameEngine.getInstance().getSelectedPosition().get())
                        .forEach(x -> {
                            gridGame.addHighlightDecorator(x.getFinalPosition().getId());});
            } else {
                if (index < 0) {
                    markers.addHighlightDecorator(index);
                } else {
                    gridGame.addHighlightDecorator(index);
                }
            }
        }
        if (GameEngine.getInstance().isSelectedUndoable()) { // undo highlight
            if (GameEngine.getInstance().getSelectedPosition().get() < 0) {
                markers.addUndoDecorator(GameEngine.getInstance().getSelectedPosition().get());
            } else {
                gridGame.addUndoDecorator(GameEngine.getInstance().getSelectedPosition().get());
            }
        }
        this.scorePanel.updateScore(this.gameEngine.getCurrentPlayer().getId(), this.gameEngine.getPhaseState().toString());
        this.markers.repaint();
        this.gridGame.repaint();
        this.scorePanel.repaint();

    }

    /** Overrides a method in the base class which is called whenever the UI is instructed to be repainted*/
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(new Color(0x00f0f0f0));
        g.fillRect(0, 0, getWidth(), getHeight());
    }

    /** Method to update the class when the class it listens to changes*/
    @Override
    public void update() {
        unselectButton.setEnabled(gameEngine.isSelectedUndoable());
        this.synchroniseWithGame();
    }


}

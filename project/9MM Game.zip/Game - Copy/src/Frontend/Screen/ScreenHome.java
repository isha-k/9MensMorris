package Frontend.Screen;

import Frontend.Button.ButtonCustomise;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

/**
 * The home screen of the game.
 */
public class ScreenHome extends JPanel {

    /**
     * Constructs a ScreenHome object.
     */
    public ScreenHome() {
        super();
        this.setLayout(new BorderLayout());
        this.setBackground(new Color(216, 255, 255));
        URL url = Thread.currentThread().getContextClassLoader().getResource("title.png");
        if (url != null) {
            JLabel picture = new JLabel(new ImageIcon(url));
            this.add(picture, BorderLayout.CENTER);
        } else {
            System.out.println("Picture failed to load");
        }
        this.add(new ButtonCustomise(), BorderLayout.SOUTH);
    }

}
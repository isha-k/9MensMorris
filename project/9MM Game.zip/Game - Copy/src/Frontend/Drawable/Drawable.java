package Frontend.Drawable;

import Frontend.Grids.GridGame;
import Frontend.Grids.GridMarker;

import java.awt.*;

/**
 * An interface class for components which are drawn on the UI board.
 */
public interface Drawable {

    /**
     * Draws the component on the specified Graphics object.
     * @param g The Graphics object on which to draw the component.
     */
    void draw(Graphics g);

    /**
     * Retrieves the position of the component as a Point object.
     * @return The position of the component as a Point object.
     */
    Point getPoint();

    /**
     * Retrieves the ID of the component as an array of integers.
     * @return The ID of the component as an array of integers.
     */
    int[] getId();

    /**
     * Converts a position index to a Point object.
     * @param index The index of the position.
     * @return The corresponding Point object.
     */
    default Point positionToPoint(int index) {
        if (index == Integer.MAX_VALUE) {
            return new Point(80, 24);
        }
        if (index < 0)
            return GridMarker.getInstance().positionToPoint(index);
        else { // on-board
            return GridGame.getInstance().positionToPoint(index);
        }
    }

}

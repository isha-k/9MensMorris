package Frontend.Drawable;

import java.awt.*;

/**
 * The HighlightedGrid class represents a highlighted grid on the game board.
 */
public class HighlightedGrid implements Drawable {

    private int id, row, col, cellWidth, cellHeight;

    /**
     * Constructs a HighlightedGrid object with the specified parameters.
     *
     * @param id         The ID of the highlighted grid.
     * @param row        The row index of the highlighted grid.
     * @param col        The column index of the highlighted grid.
     * @param cellWidth  The width of the grid cell.
     * @param cellHeight The height of the grid cell.
     */
    public HighlightedGrid(int id, int row, int col, int cellWidth, int cellHeight) {
        this.id = id;
        this.row = row;
        this.col = col;
        this.cellWidth = cellWidth;
        this.cellHeight = cellHeight;
    }

    /**
     * Draws the highlighted grid on the graphics context.
     *
     * @param g The Graphics object on which to draw the highlighted grid.
     */
    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.25f));
        g2d.setColor(Color.GREEN);
        g2d.fillRect(row, col, cellWidth, cellHeight);
    }

    /**
     * Gets the point representing the highlighted grid.
     *
     * @return The point representing the highlighted grid.
     */
    @Override
    public Point getPoint() {
        int positionRow = row + cellWidth / 2;
        int positionCol = col + cellHeight / 2;
        return new Point(positionRow, positionCol);
    }

    /**
     * Gets the ID of the highlighted grid.
     *
     * @return An array containing the ID of the highlighted grid.
     */
    @Override
    public int[] getId() {
        return new int[]{id};
    }
}

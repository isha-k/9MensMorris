package Frontend.Drawable;

import java.awt.*;

public abstract class Decorator extends NodeAbstract {

    /**
     * Constructor
     * @param id identifier of the decorator
     * @param p position of the decorator in the UI
     * @param color color of the decorator in the UI
     * @param borderSize bordersize of the decorator in the UI
     **/
    public Decorator(int id, Color color, double borderSize) { super(id, color, borderSize); }


    /** Fill shape is overriden because decorators are not filled with any color */
    @Override
    public void fillShape(Graphics g) {}


}

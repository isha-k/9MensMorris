package Frontend.Drawable;

import Frontend.GameConstant;

import java.awt.*;

public class BoxTurn implements Drawable {

    /** OD of the current player */
    private int playerId;

    /** String denoting the current phase */
    private String phase;

    /**
     * Draws the turn box on the graphics context.
     * The turn box displays the current player's turn and phase information.
     *
     * @param g the Graphics object on which to draw the turn box
     */
    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        // Textbox border
        g2d.setColor(Color.BLACK);
        DrawableFactory.createNode(Integer.MAX_VALUE, playerId).draw(g);
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawRect(0, 0, GameConstant.BOARD_WIDTH, GameConstant.BOX_HEIGHT);
        // String drawing
        g2d.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.BOLD, 12);
        g2d.setFont(font);
        String turnString = String.format("Player %s's turn", this.playerId);
        String phaseString = String.format("Please %s a marker.", this.phase);
        g2d.drawString(turnString, 130, 20);
        g2d.drawString(phaseString, 115, 35);
    }

    /**
     * Creates a new BoxTurn object with the specified player ID and phase.
     *
     * @param playerId the unique identifier of the player
     * @param phase    the current phase of the game
     */
    public BoxTurn(int playerId, String phase) {
        this.playerId = playerId;
        this.phase = phase;
    }

    @Override
    public Point getPoint() { return new Point (0,0); }

    @Override
    public int[] getId() { return new int[] { playerId }; }

}

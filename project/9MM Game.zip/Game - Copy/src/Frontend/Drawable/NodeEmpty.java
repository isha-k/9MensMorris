package Frontend.Drawable;

import Frontend.GameConstant;

import java.awt.*;

/**
 * The EmptyNode class represents the visual of an unoccupied position on the game board.
 */
public class NodeEmpty extends NodeAbstract {

    /**
     * Constructs a NodeEmpty object with the specified ID.
     *
     * @param id The ID of the empty node.
     */
    public NodeEmpty(int id) {
        super(id, Color.BLACK, GameConstant.EMPTY_NODE_SIZE);
    }

}
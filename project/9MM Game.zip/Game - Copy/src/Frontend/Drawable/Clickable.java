package Frontend.Drawable;

import java.awt.*;

/**
 * The Clickable interface represents an object that can be clicked or interacted with.
 */
public interface Clickable {

    /**
     * Checks if the clickable object contains the given point.
     *
     * @param point The point to check.
     * @return true if the clickable object contains the point, false otherwise.
     */
    boolean containsPoint(Point point);

    /**
     * Retrieves the identifier of the clickable object.
     *
     * @return The identifier of the clickable object.
     */
    int getIdentifier();

}

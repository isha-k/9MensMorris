package Frontend.Drawable;

import Frontend.GameConstant;

import java.awt.*;

/**
 * The DecoratorUndo class represents the visual of a positional highlight on the game board.
 */
public class DecoratorUndo extends Decorator {

    /**
     * Constructs a new DecoratorUndo instance with the specified position ID.
     * The DecoratorUndo visual is represented by a red color and a specific highlight size.
     *
     * @param positionId The ID of the position to apply the decorator to.
     */
    public DecoratorUndo(int positionId) {
        super(positionId, Color.RED, GameConstant.HIGHLIGHT_SIZE);
    }

}
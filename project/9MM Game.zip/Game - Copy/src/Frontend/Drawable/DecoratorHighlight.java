package Frontend.Drawable;

import Frontend.GameConstant;

import java.awt.*;

/**
 * The DecoratorHighlight class represents the visual of a positional highlight on the game board.
 */
public class DecoratorHighlight extends Decorator implements Clickable {

    int id; // The identifier of the decorator

    /**
     * Constructs a new DecoratorHighlight instance with the specified position ID.
     * The DecoratorHighlight visual is represented by a green color and a specific highlight size.
     *
     * @param positionId The ID of the position to apply the decorator to.
     */
    public DecoratorHighlight(int positionId) {
        super(positionId, Color.GREEN, GameConstant.HIGHLIGHT_SIZE);
        id = positionId;
    }

    /**
     * Overrides the fillShape method to provide an empty effect.
     *
     * @param g The Graphics object used to fill the shape.
     */
    @Override
    public void fillShape(Graphics g) {}

    /**
     * Checks if the decorator contains the given point.
     *
     * @param point The point to check.
     * @return true if the decorator contains the point, false otherwise.
     */
    @Override
    public boolean containsPoint(Point point) {
        return super.contains(point);
    }

    /**
     * Retrieves the identifier of the decorator.
     *
     * @return The identifier of the decorator.
     */
    @Override
    public int getIdentifier() {
        return id;
    }

    /**
     * Retrieves the ID as an array of integers.
     *
     * @return The ID as an array of integers.
     */
    @Override
    public int[] getId() {
        return new int[id];
    }

    /**
     * Converts a position index to a Point object.
     *
     * @param index The index of the position.
     * @return The corresponding Point object.
     */
    @Override
    public Point positionToPoint(int index) {
        return super.positionToPoint(index);
    }
}
package Frontend.Drawable;

import Frontend.GameConstant;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

/**
 * The FilledNode class represents the visual of an occupied position on the game board.
 */
public class NodeFilled extends NodeAbstract {


    /**
     * different colors nodes can have based on a players id, these colors are chosen before a random color is chosen
     */
    private static List<Color> colorArray = new ArrayList<>(Arrays.asList(Color.WHITE, Color.BLACK, Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA));

    /**
     * generates a random color for the player all colors in colorArray have been taken
     */
    private static Color getColor(int id) {
        Random random = new Random();
        while (NodeFilled.colorArray.size() < id + 1) {
            NodeFilled.colorArray.add(new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        }
        return NodeFilled.colorArray.get(id-1);
    }


    /**
     * mathematically determines the opposite color to color, which still makes the color accessible if they are placed on top of each other.
     */
    private static Color getOppositeColor(Color color) {
        int red = (((color.getRed() / 128) + 1) % 2) * 255;
        int green = (((color.getGreen() / 128) + 1) % 2) * 255;
        int blue = (((color.getBlue() / 128) + 1) % 2) * 255;
        return new Color(red, green, blue);
    }

    /**
     * Constructs a NodeFilled object with the specified position ID and player ID.
     *
     * @param positionId The position ID of the node.
     * @param playerId   The player ID.
     */
    public NodeFilled(int positionId, int playerId) {
        super(positionId, NodeFilled.getColor(playerId), GameConstant.MARKER_NODE_SIZE);
        //A consumer function (an anonymous function which accepts parameters) indicating to draw this specific node
        Consumer<Graphics2D> drawPlayerId =
                (Graphics2D g) -> {
                    g.setFont(new Font("Arial", Font.BOLD, 12));
                    g.setColor(NodeFilled.getOppositeColor(color));
                    String number = Integer.toString(playerId);
                    double textWidth = g.getFontMetrics().stringWidth(number);
                    double textHeight = g.getFontMetrics().getHeight();
                    int textX = (int) (positionToPoint(positionId).getX() - (textWidth / 2));
                    int textY = (int) (positionToPoint(positionId).getY() + (textHeight / 2));
                    g.drawString(number, textX, textY);
        };
        //Adds this consumer function to the list of anonymous functions which can be supplemented to customise drawing of nodes
        this.addAdditionalDraw(drawPlayerId);
    }

}
package Frontend.Drawable;

import java.awt.*;
import java.util.ArrayList;
import java.util.function.Consumer;

/**
 * A Node represents a node in a graph.
 */
public abstract class NodeAbstract implements Drawable {

    /**
     * Position of the node in the UI Screen
     */
    private Point p;

    /**
     * Id of node to match node with position representation in backend
     */
    private int id;

    /**
     * The rectangle graphic of the node
     */
    protected Rectangle b = new Rectangle();

    /**
     * Color to fill of node in UI screen
     */
    protected Color color;

    /**
     * Size of node in UI screen
     */
    private double borderSize;

    private ArrayList<Consumer<Graphics2D>> additionalDraws = new ArrayList<>();

    /**CONSTRUCTORS**/


    /**
     * Constructs a NodeAbstract object with the specified ID, color, and border size.
     *
     * @param id         The ID of the node.
     * @param color      The color used to fill the node in the UI screen.
     * @param borderSize The size of the node in the UI screen.
     */
    public NodeAbstract(int id, Color color, double borderSize) {
        this.id = id;
        this.p = positionToPoint(id);
        this.color = color;
        this.borderSize = borderSize;
        setBoundary(b);
    }

    /**GETTERS**/

    /**
     * Adds an additional draw operation to be performed on the node.
     *
     * @param lambda The additional draw operation.
     */
    public void addAdditionalDraw(Consumer lambda){
        additionalDraws.add(lambda);
    }


    /**METHODS**/

    /**
     * Calculate this node's rectangular boundary.
     */
    private void setBoundary(Rectangle b) {
        int r = (int) this.borderSize;
        b.setBounds(p.x - r, p.y - r, 2 * r, 2 * r);
    }

    /**
     * Draws this node on the UI screen.
     *
     * @param g The Graphics object on which to draw the node.
     */
    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(this.color);
        g.drawOval(b.x, b.y, b.width, b.height);
        this.fillShape(g);
        for (Consumer draws: this.additionalDraws) {
            draws.accept(g2d);
        }

    }
    /**
     * Fill this node with a certain color.
     */
    protected void fillShape(Graphics g){
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(this.color);
        g2d.fillOval(b.x, b.y, b.width, b.height);
        g2d.setColor(Color.BLACK);
        g2d.drawOval(b.x, b.y, b.width, b.height);
    }

    /**
     * Checks if this node contains the specified point.
     *
     * @param p The point to check.
     * @return `true` if this node contains the point, `false` otherwise.
     */
    public boolean contains(Point p) {
        return b.contains(p);
    }

    /**
     * Returns the position of this node.
     *
     * @return The position of the node.
     */
    @Override
    public Point getPoint(){
        return p;
    }

    /**
     * Returns the ID of this node.
     *
     * @return The ID of the node.
     */
    public int[] getId(){
        return new int[]{id};
    }

}
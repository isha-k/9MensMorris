package Frontend.Drawable;

import Backend.GameEngine;
import Frontend.Grids.GridMarker;

import java.awt.*;

/**
 * A textbox to represent the players score
 */
public class BoxScore implements Drawable {

    /** the players score */
    private int playerScore;

    /** the players identifier */
    private int playerId;

    /** the x-coordinate */
    private int x;

    /** the y-coordinate */
    private int y;


    /**
     * Draws the player's score box on the graphics context.
     * The player's score box displays the player's ID and score.
     *
     * @param g is the Graphics object on which to draw the score box
     */
    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLACK);
        y += g.getFontMetrics().getHeight() / 2;
        System.out.println("PLAYER SCORE IN BOX SCORE " + this.playerScore);
        g2d.drawString(String.format("P%s score: %s", this.playerId, this.playerScore), x, y);
    }

    /**
     * Constructs a new BoxScore instance with the specified player ID and score.
     *
     * @param playerId   the unique identifier of the player
     * @param playerScore the score of the player
     */
    public BoxScore(int playerId, int playerScore) {
        this.playerScore = playerScore;
        this.playerId = playerId;
        this.x = Math.round((-1 * (-1 * GameEngine.getInstance().getOffsetMax() - 1)) * GridMarker.getInstance().getCellWidth() - GridMarker.getInstance().getCellWidth()/2 );
        this.y = Math.round((-1 + playerId) * GridMarker.getInstance().getCellHeight()+ GridMarker.getInstance().getCellHeight() / 2);}

    /**
     * Overrides the getPoint method from the Drawable interface.
     * Retrieves the point as a java.awt.Point object.
     * @return The point as a java.awt.Point object.
     */
    @Override
    public Point getPoint(){
        return new Point(x, y);
    }

    /**
     * Overrides the getId method from the Drawable interface.
     * Retrieves the ID as an array of integers.
     * @return The ID as an array of integers.
     */
    @Override
    public int[] getId(){
        return new int[] { playerId };
    }

}


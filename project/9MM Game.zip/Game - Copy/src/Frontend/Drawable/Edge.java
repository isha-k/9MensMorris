package Frontend.Drawable;

import java.awt.*;

/**
 * The Edge class defines the visual element (line) that connects up two board positions, or visual nodes.
 */
public class Edge implements Drawable {

    /** location of the two nodes to be connected, represented by a point*/
    private Point p1, p2;

    /** The ID of the first node. */
    private int node1;

    /** The ID of the second node. */
    private int node2;

    /**
     * Constructs an Edge object that connects two nodes.
     *
     * @param node1 The ID of the first node.
     * @param node2 The ID of the second node.
     */
    public Edge(int node1, int node2) {
        this.p1 = positionToPoint(node1);
        this.p2 = positionToPoint(node2);
        this.node1 = node1;
        this.node2 = node2;

    }

    /**
     * Draws the edge on the graphics context.
     *
     * @param g The Graphics object on which to draw the edge.
     */
    @Override
    public void draw(Graphics g) {
        g.setColor(Color.DARK_GRAY);
        g.drawLine(this.p1.x, this.p1.y, this.p2.x, this.p2.y);
    }

    /**
     * Gets the point representing the first node of the edge.
     *
     * @return The point representing the first node.
     */
    @Override
    public Point getPoint(){
        return p1;
    }

    /**
     * Gets the IDs of the two nodes connected by the edge.
     *
     * @return An array containing the IDs of the two nodes.
     */
    @Override
    public int[] getId(){
        return new int[]{node1,node2};
    }

}
package Frontend.Drawable;

import Backend.GameEngine;

/**
 * A abstract factory method to generate all the UI elements in the nine man's morris game.
 */
public class DrawableFactory {


    /**
     * Creates a Drawable object representing a node with a marker or an empty position.
     *
     * @param positionId The ID of the position.
     * @param playerId   The ID of the player.
     * @return The Drawable object representing the node.
     */
    public static Drawable createNode(int positionId, int playerId) {
        return new NodeFilled(positionId, playerId); // constructor for on-board pos (filled) and scoreboard pos
    }

    /**
     * Creates a Drawable object representing a marker.
     *
     * @param positionId The ID of the position.
     * @return The Drawable object representing the marker.
     */
    public static Drawable createMarker(int positionId) {
        int playerId = (int) Math.ceil(-1 * ((double) positionId / (double) GameEngine.getInstance().getOffsetMax()));// offset
        return new NodeFilled(positionId, playerId);
    }

    /**
     * Creates a Drawable object representing an empty node.
     *
     * @param positionId The ID of the position.
     * @return The Drawable object representing the empty node.
     */
    public static Drawable createEmptyNode(int positionId) {
        return new NodeEmpty(positionId);
    }


    /**
     * Creates a Decorator object that shows which marker can be clicked on.
     *
     * @param positionId The ID of the position.
     * @return The Decorator object representing the highlighted position.
     */
    public static Drawable createHighlightedDecorator(int positionId) {
        System.out.println("I AM THE DECORATOR");
        return new DecoratorHighlight(positionId); }

    /**
     * Creates a Decorator object that shows the marker which can be undone.
     *
     * @param positionId The ID of the position.
     * @return The Decorator object representing the position to undo.
     */
    public static Drawable createUndoDecorator(int positionId) { return new DecoratorUndo(positionId); }

    /**
     * Creates a Drawable object representing a line between two positions.
     *
     * @param node1 The ID of the first position.
     * @param node2 The ID of the second position.
     * @return The Drawable object representing the line between positions.
     */
    public static Drawable createEdge(int node1, int node2) { return new Edge(node1, node2); }

    /**
     * Creates a Drawable object representing a player's score on the UI.
     *
     * @param playerId    The ID of the player.
     * @param playerScore The score of the player.
     * @return The Drawable object representing the player's score.
     */

    public static Drawable createBoxScore(int playerId, int playerScore) { return new BoxScore(playerId, playerScore); }

    /**
     * Creates a Drawable object representing the turn board that shows the next player and phase.
     *
     * @param playerId The ID of the player.
     * @param phase    The phase of the game.
     * @return The Drawable object representing the turn board.
     */
    public static Drawable createBoxTurn(int playerId, String phase) { return new BoxTurn(playerId, phase); }

    /**
     * Creates a Drawable object representing a highlighted grid.
     *
     * @param id         The ID of the grid.
     * @param row        The row of the grid.
     * @param col        The column of the grid.
     * @param cellWidth  The width of each cell in the grid.
     * @param cellHeight The height of each cell in the grid.
     * @return The Drawable object representing the highlighted grid.
     */
    public static Drawable createHighlightedGrid(int id, int row, int col, int cellWidth, int cellHeight) {
        return new HighlightedGrid(id, row, col, cellWidth, cellHeight);
    }


}







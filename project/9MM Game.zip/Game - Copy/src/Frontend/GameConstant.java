// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// NOTE: THIS CLASS IS ONLY A TEMPORARY CLASS!!!!!!
// We used to have all those hard-coded values in spread all around the world with GUI coordinates
// Figured that we should get at least a place to store those values in
// so it'd be easier with consistency without having to scramble all around the world just to look for relevant variables

package Frontend;

public class GameConstant {
    public static int MARKER_NODE_SIZE = 12;
    public static int EMPTY_NODE_SIZE = 4;
    public static int HIGHLIGHT_SIZE = 14;
    public static int BOARD_WIDTH = 320;
    public static int BOARD_HEIGHT = 320;

    public static int HORIZONTAL_PADDING = 64;

    public static int BOX_HEIGHT = 48;
}

package Frontend.MouseHandler;

import Backend.GameEngine;
import Frontend.Grids.ClickableContainer;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * The GameEngine class is responsible to initialising the game
 * dictating the game loop
 * //CONTROLLER IN MODEL VIEW CONTROLLER
 */

public class ControllerGame extends MouseAdapter {

    /** view of the game */
    private ClickableContainer clickableContainer;
    private GameEngine gameEngine = GameEngine.getInstance();

    public ControllerGame(ClickableContainer clickableContainer) {
        this.clickableContainer = clickableContainer;
    }

    /**
     * Called when a mouse button is pressed.
     *
     * @param e the MouseEvent object
     */
    @Override
    public void mousePressed(MouseEvent e) {
        Point mousePt = e.getPoint();
        handleEvent(mousePt);
    }

    /**
     * Handles the mouse event by determining the action to be performed based on the clicked position.
     *
     * @param p the point where the mouse was clicked
     */
    public void handleEvent(Point p)  { // this whole chunk is possible to make it not rely on Decorator (or formerly it was reliant on Node and Highlight)
        // if the game has stopped, don't change the gameEngine
        if (! GameEngine.getInstance().isGameRunning()) { return; }
        clickableContainer
                .getClickables()
                .stream()
                .filter(clickable -> clickable.containsPoint(p))
                .forEach(decorator -> {
                    //get decorators identifier
                    int id = decorator.getIdentifier();
                    // if the user has previously selected a marker and selects a final position
                    if (!gameEngine.getSelectedPosition().isEmpty() && gameEngine.playerSelectedFinalPosition(id)) {
                        //execute the action command corresponding to the position
                        gameEngine.executeAction(gameEngine.getSelectedAction(decorator.getIdentifier()));
                        //set the last selected position to be the decorators id
                        gameEngine.setSelectedPosition(decorator.getIdentifier());
                        // continue the game
                        gameEngine.gameLoop();
                        return;
                    }
                    //in other situations
                    //set the last selected position to be the decorators id
                    gameEngine.setSelectedPosition(decorator.getIdentifier());
                    //update all observers listening to the gameEngine class
                    gameEngine.notifyChange();
                });
    }

}


package Frontend.MouseHandler;

import Frontend.Drawable.DrawableFactory;
import Frontend.Grids.GridCustomise;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ControllerCustomise extends MouseAdapter {

    public GridCustomise grid;

    public ControllerCustomise(GridCustomise grid) {
        this.grid = grid;
    }

    /**
     * Called when a mouse button is pressed.
     *
     * @param e the MouseEvent object
     */
    @Override
    public void mousePressed(MouseEvent e) {
        Point mousePt = e.getPoint();
        handleEvent(mousePt);
    }

    /**
     * Handles the mouse event by determining the action to be performed based on the clicked position.
     *
     * @param p the point where the mouse was clicked
     */
    public void handleEvent(Point p) {
        int x = (int) p.getX();
        int y = (int) p.getY();
        int cellWidth = this.grid.getCellWidth();
        int cellHeight = this.grid.getCellHeight();
        int row = y / this.grid.getCellHeight();
        int col = x / this.grid.getCellWidth();
        int highlightedRow = Math.round(col * cellWidth);
        int highlightedCol = Math.round(row * cellHeight);
        int nodeId = row * this.grid.gridWidth + col;
        if(grid.gridChecker[col][row]){
            if (this.grid.drawables.stream().anyMatch(id -> id.getId()[0] == nodeId)) {
                if (!this.grid.highlightedQueue.stream().anyMatch(id -> id.getId()[0] == nodeId)){
                    this.grid.highlightedQueue.add(DrawableFactory.createHighlightedGrid(nodeId, highlightedRow, highlightedCol, cellWidth, cellHeight));
                    if (this.grid.highlightedQueue.size() == 3) {
                        this.grid.highlightedQueue.poll(); // Remove the first object when capacity is reached
                    }
                }
            }
        } else {
            this.grid.addPosition(row * this.grid.gridWidth + col, null);
            grid.gridChecker[this.grid.getRow(nodeId)][this.grid.getCol(nodeId)] = true;

        }
        this.grid.invalidate();
        this.grid.repaint();
    }

}



package Frontend.Panels;

import Frontend.Drawable.Drawable;
import Frontend.Drawable.DrawableFactory;
import Frontend.GameConstant;

import javax.swing.*;
import java.awt.*;

import static Frontend.GameConstant.BOARD_WIDTH;

public class PanelTurn extends JPanel {

    private Drawable boxTurn;

    public PanelTurn() {
        this.setLayout(new FlowLayout());
        this.setPreferredSize(new Dimension(BOARD_WIDTH, GameConstant.BOX_HEIGHT));
    }

    public void updateScore(int player, String phase) {
        this.boxTurn = DrawableFactory.createBoxTurn(player, phase);
    }

    @Override
    public void paintComponent(Graphics g) {
        this.boxTurn.draw(g);
    }

}

package Frontend.Panels;

import Backend.Action.Action;
import Backend.GameEngine;
import Frontend.Grids.GridGame;
import Frontend.Grids.GridMarker;
import Frontend.Observer;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * The GraphPanel class is responsible for the main visual layout of the Nine Men's Morris game.
 * The GraphPanel class is the View class in the MVC model.
 */

public class PanelGraph extends JComponent implements Observer {

    private GameEngine gameEngine;
    private GridGame gridGame;
    private GridMarker markers;
    private PanelTurn scorePanel;

    /**
     * Constructs a new GraphPanel object with the specified game engine.
     *
     */
    public PanelGraph() {
        this.setOpaque(true); // Set opaque
        this.gameEngine = GameEngine.getInstance(); // Set gameEngine instance
        this.gameEngine.attach(this); // Add current class and mouse handler as observers of changes to gameEngine instance
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 16));
        this.gridGame = GridGame.getInstance();
        this.add(gridGame);
        this.scorePanel = new PanelTurn();
        this.add(scorePanel);
        this.markers = GridMarker.getInstance();
        this.add(markers);
    }

    /**
     * Draws the game graphically by creating and adding the visual elements to the collection.
     */
    public void synchroniseWithGame(){
        Map<Integer, List<Action>> gameActions = GameEngine.getInstance().getNextActions();
        this.gridGame.modifyGrid();
        this.markers.modifyGrid();
        for (int index : gameActions.keySet()) {
            if (GameEngine.getInstance().playerSelectedMarkerActionMarker()) {
                gameActions.get(GameEngine.getInstance().getSelectedPosition().get())
                        .forEach(x -> {
                            gridGame.addHighlightDecorator(x.getFinalPosition().getId());
                        });
            } else {
                if (index < 0) {
                    markers.addHighlightDecorator(index);
                } else {
                    gridGame.addHighlightDecorator(index);
                }
            }
        }
        if (GameEngine.getInstance().isSelectedUndoable()) { // undo highlight
            if (GameEngine.getInstance().getSelectedPosition().get() < 0) {
                markers.addUndoDecorator(GameEngine.getInstance().getSelectedPosition().get());
            } else {
                gridGame.addUndoDecorator(GameEngine.getInstance().getSelectedPosition().get());
            }
        }
        this.scorePanel.updateScore(this.gameEngine.getCurrentPlayer().getId(), this.gameEngine.getPhaseState().toString());
//        this.scorePanel.repaint();
        this.markers.repaint();
        this.gridGame.repaint();
    }

    /** Method to update the class when the class it listens to changes*/
    @Override
    public void update() {
        this.synchroniseWithGame();
    }

}




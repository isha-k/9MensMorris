package Frontend.Panels;

import Frontend.Button.ButtonStart;
import Frontend.Grids.GridCustomise;
import Frontend.Screen.ScreenCustomise;

import javax.swing.*;

public class PanelControl extends JPanel {

    private JTextField fieldGridSize;

    public PanelControl(GridCustomise panelGrid, ScreenCustomise screenCustomise) {
        JButton defaultButton = new JButton("Reset");
        defaultButton.addActionListener(e -> { screenCustomise.reset(); });
        this.fieldGridSize = new JTextField(4);
        JButton drawButton = new JButton("Draw Grid");
        drawButton.addActionListener(e -> {
            String gridSizeText = fieldGridSize.getText();
            try {
                int gridSize = Integer.parseInt(gridSizeText);
                panelGrid.changeGridSize(gridSize,gridSize);
                panelGrid.modifyGrid();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid grid size!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        this.add(defaultButton);
        this.add(new JLabel("Grid Size:"));
        this.add(fieldGridSize);
        this.add(drawButton);
        this.add(new ButtonStart(screenCustomise, panelGrid));
    }

}
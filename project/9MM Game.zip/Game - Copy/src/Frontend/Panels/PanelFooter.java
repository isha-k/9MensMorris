package Frontend.Panels;

import Frontend.Button.ButtonBack;
import Frontend.Grids.GridCustomise;

import javax.swing.*;
import java.awt.*;

public class PanelFooter extends JPanel {

    public PanelFooter(GridCustomise gridCustomise) {
        this.setLayout(new FlowLayout());
        this.add(new ButtonBack());
        JButton connectButton = new JButton("Connect");
        connectButton.addActionListener(x -> gridCustomise.connectNodes());
        this.add(connectButton);
    }

}
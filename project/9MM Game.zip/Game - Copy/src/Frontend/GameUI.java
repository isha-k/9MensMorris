package Frontend;

import Backend.GameEngine;
import Frontend.Button.ButtonAbstract;
import Frontend.Button.ButtonUnselect;
import Frontend.Panels.PanelGraph;
import Frontend.Screen.ScreenCustomise;
import Frontend.Screen.ScreenGame;
import Frontend.Screen.ScreenHome;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/*
   Happy FIT3077!

   Authors:
   Isha Kaur
   Michelle Wong
   William Wei
*/


/**
 * The GameUI is the core UI and bootstrap class to start an nine mans morris game.
 */
public class GameUI implements Observer {

    /**
     * The Window of the Game
     */
    public static JFrame frame;

    /**
     * The main container of panels in the UI
     */
    public static JPanel homeContainer;

    /**
     * The layout of the UI
     */
    public static CardLayout layout;

    /**
     * The Game Screen
     */
    public static ScreenGame screenGame;

    /**
     * The Home screen
     */
    public static ScreenHome screenHome;

    /**
     * The Customise Board screen
     */
    public static ScreenCustomise screenCustomise;

    /**
     * The class responsible for storing the game state
     */
    public static GameEngine gameEngine;

    /**
     * Initializes the GameUI class and starts the game.
     */
    public GameUI() {
        System.setProperty("sun.awt.noerasebackground", "true");
        if (frame != null) { frame.dispose(); }
        //create window
        frame = new JFrame("Nine Men's Morris");
        // set size of window
        frame.setPreferredSize(new Dimension(GameConstant.BOARD_WIDTH + 2 * GameConstant.HORIZONTAL_PADDING, 720));
        frame.setResizable(false);
        // dispose frame when it is closed
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.pack();
        frame.setVisible(true);
        // set layout of window
        layout = new CardLayout(0, 0);
        // set main layout container of window
        homeContainer = new JPanel(layout);
        frame.add(homeContainer);
        gameEngine =  GameEngine.getInstance();
        gameEngine.attach(this);
        screenGame = new ScreenGame();
        homeContainer.add(screenGame, "Game Panel");
        screenCustomise = new ScreenCustomise();
        homeContainer.add(screenCustomise, "Customise Panel");
        screenHome = new ScreenHome();
        homeContainer.add(screenHome, "Game Home");
        layout.show(homeContainer, "Game Home");
    }


    /**
     * handles what happens when a game ends.
     */
    public static void handleGameEnd() {
        String message = String.format("Game over!%nPlayer %s wins!", gameEngine.getGameEndWinner().getId());
        layout.show(homeContainer, "Game Panel");
        JOptionPane.showOptionDialog( //show dialogue
                null,
                message,
                "Game Over",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null, new Object[]{"Restart"},
                "Restart");
        new GameUI();
    }

    /**
     * Updates when gameEngine changes
     */
    @Override
    public void update() {
        if (! gameEngine.isGameRunning() && screenGame.isVisible()) { handleGameEnd(); } // If the game isn't running, handle game end
    }

    /** It's the PSVM method!
     * @param args String args.
     */
    public static void main(String[] args) { SwingUtilities.invokeLater(GameUI::new); }

}
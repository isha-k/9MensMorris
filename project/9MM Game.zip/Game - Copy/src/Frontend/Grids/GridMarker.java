package Frontend.Grids;

import Backend.GameEngine;
import Backend.Player;
import Frontend.Drawable.Clickable;
import Frontend.Drawable.Drawable;
import Frontend.Drawable.DrawableFactory;
import Frontend.MouseHandler.ControllerGame;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import static Frontend.GameConstant.BOARD_WIDTH;
import static Frontend.GameConstant.HORIZONTAL_PADDING;


public class GridMarker extends Grid implements ClickableContainer, DecoratorEnabled {

    private static GridMarker reference;
    public static List<Drawable> drawables = new ArrayList<>();

    private GridMarker() {
        super(BOARD_WIDTH + HORIZONTAL_PADDING * 3 / 2, 256);
        this.gridWidth = 9 + 3;
        this.gridHeight = 8;
        this.setPreferredSize(new Dimension(width, height));
        ControllerGame controllerGame = new ControllerGame(this);
        this.addMouseListener(controllerGame);
    }

    public static GridMarker getInstance() {
        if (reference == null) { reference = new GridMarker(); }
        return reference;
    }

    public void initialiseGrid(int gridWidth, int gridHeight){
        this.gridWidth = gridWidth + 3;
        this.gridHeight = Math.max(gridHeight, 8);
    }

    @Override
    public int getRow(int index) {return index * -1 -1 - (GameEngine.getInstance().getOffsetMax() * getCol(index)); }

    @Override
    public int getCol(int index) {return (int) Math.ceil(-1 * ((double) index / (double) GameEngine.getInstance().getOffsetMax())) - 1; // offset
    }

    @Override
    public void modifyGrid(){
        drawables.clear();
        for (Player player : GameEngine.getInstance().getPlayers()) { // draw all offset positions
            for (int i = 1; i <= player.getOffsetCount(); i++) {
                int index = -1 * (i + ((player.getId()-1) * GameEngine.getInstance().getOffsetMax()));
                drawables.add(DrawableFactory.createMarker(index));
            }
        }
    }

    @Override
    public Point positionToPoint(int index) {
        int positionRow = Math.round((getRow(index)) * getCellWidth() + getCellWidth() / 2);
        int positionCol = Math.round((getCol(index)) * getCellHeight()+ getCellHeight() / 2);
        return new Point(positionRow,positionCol);
    }

    @Override
    public Collection<Clickable> getClickables(){
        return this.drawables.stream().filter(x -> x instanceof Clickable).map(Clickable.class::cast).collect(Collectors.toList());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Player player: GameEngine.getInstance().getPlayers()) { // draw player scores
            DrawableFactory.createBoxScore(player.getId(), player.getPlayerScore()).draw(g);
        }
        for (Drawable drawable : drawables) {
            drawable.draw(g);
        }
    }

    @Override
    public List<Drawable> getDrawables() {
        return drawables;
    }

}

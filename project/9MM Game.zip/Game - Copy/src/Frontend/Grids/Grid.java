package Frontend.Grids;

import javax.swing.*;
import java.awt.*;

public abstract class Grid extends JPanel {

    public int gridWidth;
    public int gridHeight;
    public int width;
    public int height;

    public Grid(int width, int height) {
        this.width = width;
        this.height = height;
        this.setPreferredSize(new Dimension(width, height));
    }

    public int getCellWidth() { return width / gridWidth; }
    public int getCellHeight() { return height / gridHeight; }
    public int getRow(int index) { return index % gridHeight; }
    public int getCol(int index) { return index / gridWidth; }

    public Point positionToPoint(int index) {
        int positionRow = Math.round((getRow(index)) * this.getCellWidth() + getCellWidth() / 2);
        int positionCol = Math.round((getCol(index)) * this.getCellHeight() + getCellHeight() / 2);
        return new Point(positionRow, positionCol);
    }

    public static void changeGridSize(int gridWidth, int gridHeight) {
        GridGame.getInstance().gridWidth = gridWidth;
        GridGame.getInstance().gridHeight = gridWidth;
        GridCustomise.getInstance().gridWidth = gridWidth;
        GridCustomise.getInstance().gridHeight = gridHeight;
    }

    abstract public void modifyGrid();

}





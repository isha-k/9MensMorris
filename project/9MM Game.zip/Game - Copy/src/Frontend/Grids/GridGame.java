package Frontend.Grids;

import Backend.GameEngine;
import Frontend.Drawable.Clickable;
import Frontend.Drawable.Drawable;
import Frontend.MouseHandler.ControllerGame;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static Frontend.GameConstant.*;

public class GridGame extends Grid implements ClickableContainer, GridBoard, DecoratorEnabled{

    public List<Drawable> drawables;
    public static GridGame reference;

    private GridGame(){
        super(BOARD_WIDTH, BOARD_HEIGHT);
        this.drawables = new ArrayList<>();
        this.gridWidth = 7;
        this.gridHeight = 7;
        ControllerGame controllerGame = new ControllerGame(this);
        this.addMouseListener(controllerGame);
        this.setOpaque(true);
    }

    public static GridGame getInstance() {
        if (reference == null) { reference = new GridGame(); }
        return reference;
    }

    @Override
    public List<Drawable> getDrawables() {
        return drawables;
    }

    @Override
    public void modifyGrid(){
        drawables.clear();
        GameEngine.getInstance().getGameBoard().forEach(position ->{
            position.getNeighbours().forEach(neighbour -> {
                if (position.getId() > neighbour.getId()) {
                        this.addNeighbour(position.getId(),neighbour.getId());
                }
            });
        });
        GameEngine.getInstance().getGameBoard().forEach(position ->{
                this.addPosition(position.getId(),position.getPlayerId());
        });
    }

    public Collection<Clickable> getClickables(){
        return this.drawables.stream().filter(x -> x instanceof Clickable).map(Clickable.class::cast).collect(Collectors.toList());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Drawable drawable: drawables){
            drawable.draw(g);
        }
    }

}

package Frontend.Grids;

import Frontend.Drawable.Drawable;
import Frontend.Drawable.DrawableFactory;

import java.util.List;

public interface GridBoard {

    List<Drawable> getDrawables();

    default void addPosition(Integer positionId, Integer playerId) {
        if (playerId == null){
            getDrawables().add(DrawableFactory.createEmptyNode(positionId));
        }
        else {
            getDrawables().add(DrawableFactory.createNode(positionId, playerId));
        }
    }

    default void addNeighbour(Integer position1Id, Integer position2Id) {
        getDrawables().add(DrawableFactory.createEdge(position1Id, position2Id));
    }

}

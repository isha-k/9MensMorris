package Frontend.Grids;

import Frontend.Drawable.Clickable;

import java.util.Collection;

public interface ClickableContainer {

    Collection<Clickable> getClickables();

}

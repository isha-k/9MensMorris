package Frontend.Grids;

import Frontend.Drawable.Drawable;
import Frontend.Drawable.DrawableFactory;
import Frontend.Drawable.Edge;
import Frontend.Drawable.NodeEmpty;
import Frontend.MouseHandler.ControllerCustomise;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;

import static Frontend.GameConstant.*;

public class GridCustomise extends Grid  implements GridBoard {

    public Queue<Drawable> highlightedQueue = new LinkedList<>();
    public static List<Drawable> drawables = new ArrayList<>();

    public static GridCustomise reference;
    public boolean[][] gridChecker;


    private GridCustomise() {
        super(BOARD_WIDTH, BOARD_HEIGHT);
        this.gridWidth = 7;
        this.gridHeight = 7;
        this.addMouseListener(new ControllerCustomise(this));
        this.gridChecker = new boolean[gridWidth][gridHeight];

    }

    public static GridCustomise getInstance() {
        if (reference == null) {
            reference = new GridCustomise();
        }
        return reference;
    }


    @Override
    public void modifyGrid() {
        this.removeAll();
        this.drawables.clear();
        this.setLayout(new GridLayout(gridWidth, gridHeight));
        this.gridChecker = new boolean[gridWidth][gridHeight];
        this.highlightedQueue = new LinkedList<>();
        for (int i = 0; i < gridWidth * gridHeight; i++) {
            JPanel cellPanel = new JPanel();
            cellPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            cellPanel.setOpaque(false);
            this.add(cellPanel);
        }
        this.revalidate();
        this.repaint();
    }
    public void connectNodes() { // todo: bro this input validation is poggers
        int nodeOne = highlightedQueue.remove().getId()[0];
        int nodeTwo = highlightedQueue.remove().getId()[0];
        if (ifNoNodesInBetween(calculateCellsInBetween(nodeOne,nodeTwo))){
            addNeighbour(nodeOne, nodeTwo);
        };
        this.repaint();
    }

    @Override
    public void addNeighbour (Integer position1Id, Integer position2Id){
        getDrawables().add(DrawableFactory.createEdge(position1Id, position2Id));
        disableCellsInBetween(calculateCellsInBetween(position1Id,position2Id));

    }

    private void disableCellsInBetween(List<Integer> cellsInBetween) {
        for (Integer cells: cellsInBetween) {
            int row = cells / gridWidth;
            int col = cells % gridHeight;
            this.gridChecker[row][col] = true;
        }
    }


    public boolean ifNoNodesInBetween(List<Integer> cellsInBetween){
        return cellsInBetween
                .stream()
                .noneMatch(speculatedNode ->
                        this.getDrawables()
                                .stream()
                                .filter(existingNode -> existingNode instanceof NodeEmpty)
                                .map(node -> node.getId()[0])
                                .toList()
                                .contains(speculatedNode));
    }

    private List<Integer> calculateCellsInBetween(int id1, int id2){
        int row1 = id1 / gridWidth;
        int column1 = id1 % gridHeight;

        int row2 = id2 / gridWidth;
        int column2 = id2 % gridHeight;

        List<Integer> cellsBetween = new ArrayList<>();

        // Same row
        if (row1 == row2) {
            int minColumn = Math.min(column1, column2);
            int maxColumn = Math.max(column1, column2);
            for (int column = minColumn + 1; column < maxColumn; column++) {
                int cellId = row1 * gridWidth + column;
                cellsBetween.add(cellId);
            }
        }
        // Same column
        else if (column1 == column2) {
            int minRow = Math.min(row1, row2);
            int maxRow = Math.max(row1, row2);
            for (int row = minRow + 1; row < maxRow; row++) {
                int cellId = row * gridHeight + column1;
                cellsBetween.add(cellId);
            }
        }
        // Diagonal
        else if (Math.abs(row1 - row2) == Math.abs(column1 - column2)) {
            int minRow = Math.min(row1, row2);
            int maxRow = Math.max(row1, row2);
            int minColumn = Math.min(column1, column2);
            int maxColumn = Math.max(column1, column2);
            for (int i = 1; i < maxRow - minRow; i++) {
                int row = minRow + i;
                int column = minColumn + i;
                int cellId = row * gridWidth + column;
                cellsBetween.add(cellId);
            }
        }

        return cellsBetween;
    }


    public List<List<int[]>> translateToPositions(){
        List<int[]> positions = new ArrayList<>();
        List<int[]> neighbours = new ArrayList<>();
        for (Drawable drawable : drawables) {
            if (drawable instanceof NodeEmpty) {
                positions.add(new int[] { drawable.getId()[0] });
            }
            if (drawable instanceof Edge) {
                neighbours.add(new int[] { drawable.getId()[0], drawable.getId()[1] });
            }
        }
        return List.of(positions, neighbours);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Drawable highlighted: highlightedQueue){
            highlighted.draw(g);
        }
        for (Drawable drawable : drawables) {
            drawable.draw(g);
        }
    }

    @Override
    public List<Drawable> getDrawables() {
        return drawables;
    }

}

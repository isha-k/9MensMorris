package Frontend.Grids;

import Frontend.Drawable.Drawable;
import Frontend.Drawable.DrawableFactory;

import java.util.List;

public interface DecoratorEnabled {

    List<Drawable> getDrawables();

    default void addHighlightDecorator (Integer positionId) {
        getDrawables().add(DrawableFactory.createHighlightedDecorator(positionId));
    }

    default void addUndoDecorator (Integer positionId) {
        getDrawables().add(DrawableFactory.createUndoDecorator(positionId));
    }
}

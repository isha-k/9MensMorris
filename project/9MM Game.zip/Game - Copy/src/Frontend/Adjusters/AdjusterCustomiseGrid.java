package Frontend.Adjusters;

import Frontend.Screen.ScreenCustomise;

import javax.swing.*;
import java.awt.*;

/**
 * The AdjusterCustomiseGrid class represents a panel for customizing the grid on the screen.
 */
public class AdjusterCustomiseGrid extends JPanel {

    /**
     * Constructs an AdjusterCustomiseGrid object with the specified ScreenCustomise instance.
     * @param screenCustomise The ScreenCustomise instance associated with the adjuster panel.
     */
    public AdjusterCustomiseGrid(ScreenCustomise screenCustomise) {
        this.setLayout(new BorderLayout());
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1)); // 2 rows, 1 column
        JButton threeManMorrisButton = new JButton("Three Men's Morris Board");
        threeManMorrisButton.addActionListener(x -> screenCustomise.board3mm());
        JButton sixManMorrisButton = new JButton("Six Men's Morris Board");
        sixManMorrisButton.addActionListener(x -> screenCustomise.board6mm());
        JButton nineManMorrisButton = new JButton("Nine Men's Morris Board");
        nineManMorrisButton.addActionListener(x -> screenCustomise.board9mm());
        JButton twelveManMorrisButton = new JButton("Twelve Man's Morris Board");
        twelveManMorrisButton.addActionListener(x ->screenCustomise.board12mm());
        buttonPanel.add(threeManMorrisButton);
        buttonPanel.add(sixManMorrisButton);
        buttonPanel.add(nineManMorrisButton);
        buttonPanel.add(twelveManMorrisButton);
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.add(new JLabel("Default Configurations:"));
        this.add(titlePanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.CENTER);
    }
}
package Frontend.Adjusters;

import javax.swing.*;
import java.awt.*;

/**
 * The AdjusterCustomisePlayer class represents a panel for customizing player settings.
 */
public class AdjusterCustomisePlayer extends JPanel {

    private JTextField fieldPlayerCount; // Text field for entering the player count
    private JTextField fieldMarkerCount; // Text field for entering the marker count

    /**
     * Constructs an AdjusterCustomisePlayer object.
     */
    public AdjusterCustomisePlayer() {
        this.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.add(new JLabel("Player Count:"));
        this.fieldPlayerCount = new JTextField(4);
        this.fieldPlayerCount.setText("2");
        this.add(fieldPlayerCount);
        this.add(new JLabel("Marker Count:"));
        this.fieldMarkerCount = new JTextField(4);
        this.fieldMarkerCount.setText("9");
        this.add(fieldMarkerCount);
    }

    /**
     * Sets the player count value in the text field.
     * @param string The player count value to set.
     */
    public void setFieldPlayerCount(String string) { this.fieldPlayerCount.setText(string); }

    /**
     * Sets the marker count value in the text field.
     * @param string The marker count value to set.
     */
    public void setFieldMarkerCount(String string) { this.fieldMarkerCount.setText(string); }

    /**
     * Retrieves the player count value from the text field.
     * @return The player count value as a string.
     */
    public String getFieldPlayerCount() { return this.fieldPlayerCount.getText().toString(); }

    /**
     * Retrieves the marker count value from the text field.
     * @return The marker count value as a string.
     */
    public String getFieldMarkerCount() { return this.fieldMarkerCount.getText().toString(); }

}
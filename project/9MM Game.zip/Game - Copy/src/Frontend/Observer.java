package Frontend;

/**
 * The Observer is an interface which defines the code structure of a class which listens to another class for events.
 */
public interface Observer {

    /**
     * When an event occurs in the listened class, this method is called to update the observer
     */
    void update();

}

package Backend;

import Frontend.GameConstant;

/**
 * The Player class represents a single participant in one active round of the game
 */
public class Player {

    /** The unique identifier of a player */
    private int id;

    /** The number of markers the player has not placed on the board yet. */
    private int offsetCount;

    /** The max number of markers a player starts off with */
    private int offsetMax;

    /** The number of captured markers by the player */
    private int playerScore = 0;

    private Player playerNext;
    public Player getPlayerNext() {
        if (this.playerNext.isActive()) {
            return playerNext;
        }
        return this.playerNext.getPlayerNext();
    }
    public void setPlayerNext(Player player) { this.playerNext = player; }

    private boolean isActive;
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    /**
     * Constructs a new Player instance with the specified ID.
     *
     * @param id The unique identifier of the player.
     */
    public Player(int id, int offsetCount) {
        this.id = id;
        this.offsetMax = offsetCount;
        this.offsetCount = offsetCount;
        this.playerNext = null;
        this.isActive = true;
    }

    /**
     * Retrieves the ID of the player.
     *
     * @return The ID of the player.
     */
    public int getId() { return id; }

    /**
     * Retrieves the marker position of the player.
     *
     * @return The marker position of the player.
     */
    public int getMarkerPosition() {
        return -1 * (offsetCount + ((id - 1) * this.offsetMax));
    }

    /**
     * Retrieves the score of the player.
     *
     * @return The score of the player.
     */
    public int getPlayerScore() { return playerScore; }

    /**
     * Retrieves the marker offset of the player.
     *
     * @return The marker offset of the player.
     */
    public int getOffsetCount() { return this.offsetCount; }

    /**METHODS**/

    /**
     * increments players score* */
    public void incrementPlayerScore() { playerScore += 1; }

    /**
     * decrements player offset* */
    public void decrementOffset() { offsetCount -= 1; }

    /**
     * Returns a string representation of the player.
     *
     * @return A string representation of the player.
     */
    @Override
    public String toString() {
        return String.format("Player %s", this.id + 1); // Since the first player is indexed as 0, increase it to 1 for non-tech-people readability
    }

}



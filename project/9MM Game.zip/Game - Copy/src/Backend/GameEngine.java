package Backend;

import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Board.Position;
import Backend.Policy.PolicyFactory;
import Frontend.Observer;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The GameEngine class is the driving class responsible for initialising and running an instance of a game.
 * The GameEngine class represents the model in the model-view-controller structure in the design.
 */
public class GameEngine {

    /** Static reference to the GameEngine instance */
    private static GameEngine reference;

    /**
     * Private constructor for the GameEngine class.
     */
    private GameEngine() {}

    /**
     * Retrieves the instance of the GameEngine.
     *
     * @return The instance of the GameEngine.
     */
    public static GameEngine getInstance() {
        if (reference == null) { reference = new GameEngine(); }
        return reference;
    }

    /** The boolean value that dictates whether the game is currently active */
    private boolean isGameRunning;

    /** A list of listeners to the gameEngine*/
    private Collection<Observer> observers = new ArrayList<>();

    /** The data structure that captures the virtual representation of the Nine Men's Morris game */
    private Board board;

    /** The list that stores all active player instances in the game */
    private List<Player> players;

    /** The current player who is currently having a turn */
    private Player currentPlayer;

    /** The phase of the game with which valid actions are determined */
    private Set<String> phaseState = new HashSet<>();

    /** The winner of the game, if a winner has been determined */
    private Optional<Player> winner;

    /** The next action commands available to a player*/
    private Map<Integer, List<Action>> nextActions = new HashMap<>();

    private int offsetMax;

    /** The last position selected by any player*/
    private Optional<Integer> selectedPosition;

    /**GETTERS**/

    /**
     * Retrieves the next actions for each position on the game board.
     * @return A mapping of positions to their corresponding list of actions.
     */
    public Map<Integer, List<Action>> getNextActions() { return this.nextActions; }

    /**
     * Retrieves the selected position, if available.
     * @return An optional containing the selected position, or an empty optional if no position is selected.
     */
    public Optional<Integer> getSelectedPosition() { return this.selectedPosition; }

    /**
     * Retrieves the positions on the game board.
     * @return The list of positions on the game board.
     */
    public List<Position> getGameBoard() { return this.board.getPositions(); }

    /**
     * Retrieves the game board.
     * @return The game board.
     */
    public Board getBoard() { return this.board; }

    /**
     * Checks if the game is currently running.
     * @return {@code true} if the game is running, {@code false} otherwise.
     */
    public boolean isGameRunning() { return this.isGameRunning; }

    /**
     * Retrieves the phase state.
     * @return The set of phase states.
     */
    public Set<String> getPhaseState() { return this.phaseState; }

    /**
     * Retrieves the maximum offset value.
     * @return The maximum offset value.
     */
    public int getOffsetMax() { return offsetMax; }

    /**
     * Retrieves the current player.
     * @return The current player.
     */
    public Player getCurrentPlayer() { return this.currentPlayer; }

    /**
     * Retrieves the list of players.
     * @return The list of players.
     */
    public List<Player> getPlayers() { return this.players; }


    /**
     * Retrieves the selected action for a given position ID.
     * @param id The ID of the position.
     * @return The selected action.
     */
    public Action getSelectedAction(int id) {
        return this.nextActions
                .getOrDefault(selectedPosition.get(), this.nextActions.get(id))
                .stream()
                .filter(x -> x.getFinalPosition().getId() == id)
                .toList()
                .get(0);
    }

    /**
     * Retrieves the winner of the game at its end.
     * @return The winning player.
     */
    public Player getGameEndWinner() { return this.winner.get(); }


    /**SETTERS**/
    /**
     * Sets the game running status.
     * @param isGameRunning The boolean value indicating whether the game is running or not.
     * @return The updated game running status.
     */
    public boolean setGameRunningStatus(boolean isGameRunning) { return this.isGameRunning = isGameRunning; }

    /**
     * Sets the selected position.
     * @param id The ID of the position to be set as selected.
     */
    public void setSelectedPosition(Integer id) { this.selectedPosition = Optional.ofNullable(id); }

    /** METHODS*/

    /**
     * Initialises a game of Nine Men's Morris, including the board and players.
     * */
    public void initialiseGame(int gridSize, int markerCount, int playerCount, List<List<int[]>> positions) {
        this.initialisePlayers(playerCount, markerCount);
        this.initialiseBoard(gridSize, positions);
        this.nextActions = new HashMap<>();
        this.winner = Optional.ofNullable(null);
        this.selectedPosition = Optional.ofNullable(null);
        this.setGameRunningStatus(true);
        this.gameLoop();
        this.notifyChange();
    }

    /**
     * Initialises a players of nine man morris.
     * */
    private void initialisePlayers(int playerCount, int markerCount) {
        this.offsetMax = markerCount;
        this.players = new ArrayList<>();
        for (int i = 0; i < playerCount; i++) {
            this.players.add(new Player(players.size() + 1, this.offsetMax));
        }
        for (int i = 0; i < playerCount; i++) {
            this.players.get(i).setPlayerNext(this.players.get((i + 1) % players.size()));
        }
        this.currentPlayer = players.get(this.players.size() - 1);
    }

    /**
     * Initializes the game board with the given grid size and positions.
     * @param gridSize   The size of the game board grid.
     * @param positions  The list of positions containing markers and neighbor information.
     */
    public void initialiseBoard(int gridSize, List<List<int[]>> positions) {
        List<Integer> markers = positions.get(0).stream().map(x -> x[0]).collect(Collectors.toList());
        Map<Integer, List<Integer>> neighboursMap = new HashMap<>();
        for (int[] i : positions.get(1)) {
            neighboursMap.computeIfAbsent(i[0], key -> new ArrayList<>()).add(i[1]);
        }
        this.board = new Board(gridSize, markers, neighboursMap);
    }

    /**
     * Determines the set of players which haven't lost after each round of the game
     * */
    private void setPlayersLeft() {
        for (Player player : this.players) {
            if (player.getOffsetCount() > 0 || this.board.getPositionsOfPlayer(player.getId()).size() >= 3) { } else {
                player.setActive(false);
            }
        }
    }

    /**
     * Checks if the game has ended and determines the winning player.
     * A player is considered the winner if they meet one of the following conditions:
     * 1. The player has placed all their markers on the board and has less than three markers left on the board.
     * 2. The player has placed all their marker on the board and has no valid actions (moves) remaining.
     */
    private void checkWin() {
        // Check if any player has less than three markers left on the board
        // Sorry I just had to rewrite this method. Not saying the previous approach was bad. It's just I'm dumb and I cannot comprehend one-liners for the love of God
        if (this.currentPlayer.getPlayerNext() == this.currentPlayer) {
            this.winner = Optional.of(currentPlayer);
        } else {
            if (this.nextActions.keySet().isEmpty()) {
                this.winner = Optional.of(currentPlayer);
            } else {
                this.winner = Optional.ofNullable(null);
            }
        }
        if (this.winner.isPresent()) {
            this.setGameRunningStatus(false);
        }
    }

    /** OBSERVER METHODS */
    /**
     * Attaches a listener for changes in the GameEngine
     */
    public void attach(Observer observer) { this.observers.add(observer); }

    /**
     * Detaches a listener for changes in the GameEngine
     */
    public void detach(Observer observer) { this.observers.remove(observer); }

    /**
     * Updates all listeners of the gameEngine that the gameEngine has been updated
     */
    public void notifyChange() {
        for (Observer observer : this.observers) {
            observer.update();
        }
    }


    /**METHODS WHICH UPDATE THE MODEL*/

    /**
     * Initialises the gameLoop for each round of game play, determines players and actions
     * */
    public void gameLoop() {
        this.determinePreAction();
        if (nextActions.isEmpty()) {
            this.determineNextPlayer();
            this.determinePostAction();
            this.checkWin();
        }
        this.notifyChange();
    }

    /**
     * Conducts action checking (valid remove actions) before the turn begins
     * */
    private void determinePreAction() {
        if (this.isGameRunning()) {
            this.phaseState = new HashSet<String>();
            this.nextActions = PolicyFactory.getPreActionPolicy().validActions(board, currentPlayer);
            this.nextActions.values().forEach(array -> array.forEach(x -> this.phaseState.add(x.toString())));
        }
    }

    /**
     * Determines the next player for this particular round of the game
     * */
    private void determineNextPlayer() {
        if (this.isGameRunning()) {
            this.setPlayersLeft();
            this.currentPlayer = this.currentPlayer.getPlayerNext();
        }
    }

    /**
     * Determines the next action state for this particular turn  of the game
     * */
    private void determinePostAction() {
        if (this.isGameRunning()) {
            Set<String> gameStates = new HashSet<>();
            this.nextActions = PolicyFactory.getPostActionPolicy().validActions(board, currentPlayer);
            this.nextActions.values().forEach(array -> array.forEach(x -> gameStates.add(x.toString())));
            this.phaseState = gameStates;
        }
    }

    /**
     * Determines if the player has selected a marker in the UI
     * */
    public boolean playerSelectedMarkerActionMarker() {
        return this.selectedPosition.isPresent()
                &&
                this.nextActions.keySet().stream().anyMatch(x -> x == this.selectedPosition.get());
    }

    /**
     * Determines if the player has selected a position in the UI
     * */
    public boolean playerSelectedFinalPosition(Integer number){
        return this.nextActions
                .values()
                .stream()
                .flatMap(Collection::stream)
                .anyMatch(x -> x.getFinalPosition().getId() == number);
    }




    /**
     * Executes a particular action for the user
     * */
    public void executeAction(Action action) {
        action.execute(this.getCurrentPlayer());
        this.getBoard().setLastPosition(action.getFinalPosition());
    }

    /**
     * Determines if UI action is undoble for the player, eg they have only selected a marker not a position
     * */
    public boolean isSelectedUndoable() {
        if (this.getSelectedPosition().isPresent()) {
            if (this.playerSelectedMarkerActionMarker() || this.playerSelectedFinalPosition(this.selectedPosition.get())) {
                if (! this.playerSelectedFinalPosition(this.getSelectedPosition().get())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Undo the selection of a marker
     * */
    public void unselectPosition() {
        this.setSelectedPosition(null);
        this.notifyChange();
    }

}



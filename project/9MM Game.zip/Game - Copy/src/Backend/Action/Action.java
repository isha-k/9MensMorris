package Backend.Action;

import Backend.Board.Position;
import Backend.Player;

/**
 * The Action interface defines common functions required for game movements requested by a player.
 */
public interface Action {

    /**
     * Method for getting the final position of the player's marker after the action is executed
     * @return the final position of the player's marker
     */
    Position getFinalPosition();

    /**
     * Method that executes a requested movement.
     * @param player a reference to the player that requested the movement.
     */
    void execute(Player player);

}

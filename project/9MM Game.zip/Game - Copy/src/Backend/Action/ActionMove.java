package Backend.Action;

import Backend.Board.Position;
import Backend.Move.MoveTo;
import Backend.Player;

/**
 * The ActionSlide class represents a request by a player to move self markers on board.
 * It implements the MoveAction interface.
 */
public class ActionMove implements Action {

    /** The current position of the player's piece before it is moved. */
    private Position currentPosition;

    /** The future position where the player's piece will be placed. */
    private Position futurePosition;

    /**
     * Constructor which constructs an ActionMove object with the specified current and future positions.
     *
     * @param currentPosition the current position
     * @param futurePosition  the future position
     */
    public ActionMove(Position currentPosition, Position futurePosition) {
        this.futurePosition = futurePosition;
        this.currentPosition = currentPosition;
    }

    /**
     * Method that executes a requested movement.
     * @param player a reference to the player that requested the movement.
     */
    @Override
    public void execute(Player player) {
        new MoveTo(currentPosition, futurePosition, player);
    }

    /**
     * Method for getting the final position of the player's marker after the action is executed
     * @return the final position of the player's marker
     */
    @Override
    public Position getFinalPosition() { return this.futurePosition; }


    /**
     * Method for getting a string representation of the move available on the board.
     * @return a string representation of the move available on the board.
     */
    @Override
    public String toString() { return "move"; }

}


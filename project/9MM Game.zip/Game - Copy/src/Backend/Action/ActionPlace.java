package Backend.Action;

import Backend.Board.Position;
import Backend.Move.MoveOn;
import Backend.Player;

/**
 * The ActionPlace class represents a request by a player to place self markers on board.
 * It implements the MoveAction interface.
 */
public class ActionPlace implements Action {

    /** The future position where the player's piece will be placed. */
    private Position futurePosition;

    /**
     * Constructs an ActionPlace object with the specified future position.
     *
     * @param futurePosition the future position
     */
    public ActionPlace(Position futurePosition) {
        this.futurePosition = futurePosition;
    }

    /**
     * Method that executes a requested movement.
     * @param player a reference to the player that requested the movement.
     */
    @Override
    public void execute(Player player) {
        new MoveOn(futurePosition, player);
    }

    /**
     * Method for getting the final position of the player's marker after the action is executed
     * @return the final position of the player's marker
     */
    @Override
    public Position getFinalPosition() { return this.futurePosition; }

    /**
     * Method for getting a string representation of the move available on the board.
     * @return a string representation of the move available on the board.
     */
    @Override
    public String toString() { return "place"; }

}

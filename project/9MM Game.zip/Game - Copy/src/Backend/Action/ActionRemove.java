package Backend.Action;

import Backend.Board.Position;
import Backend.Move.MoveOff;
import Backend.Player;

/**
 * The ActionRemove class represents a request by a player to remove self markers on board.
 * It implements the MoveAction interface.
 */
public class ActionRemove implements Action {

    /** The current position of the player's piece before it is moved. */
    private Position currentPosition;

    /**
     * Constructs an ActionRemove object with the specified current position.
     *
     * @param currentPosition the current position
     */
    public ActionRemove(Position currentPosition) {
        this.currentPosition = currentPosition;
    }

    /**
     * Method that executes a requested movement.
     * @param player a reference to the player that requested the movement.
     */
    @Override
    public void execute(Player player) {
        new MoveOff(currentPosition, player);
    }

    /**
     * Method for getting the final position of the player's marker after the action is executed
     * @return the final position of the player's marker
     */
    @Override
    public Position getFinalPosition() { return this.currentPosition; }

    /**
     * Method for getting a string representation of the move available on the board.
     * @return a string representation of the move available on the board.
     */
    @Override
    public String toString() { return "remove"; }

}



package Backend.Policy;

import Backend.Action.ActionPlace;
import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Board.Position;
import Backend.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Objects.isNull;


/**
 * PolicyPlace evaluates if the next move for the player is a place move based on game rules and returns
 * all the available positions the player can elicit.
 * */
public class PolicyPlace extends Policy {

    /**
     * Checks if the given board state allows the player to place markers.
     *
     * @param board  the board state
     * @param player the player
     * @return true if marker placement is allowed, false otherwise
     */
    @Override
    public boolean isAllowed(Board board, Player player){
       return player.getOffsetCount() > 0 && board.getPositions().stream().anyMatch(x -> isNull(x.getPlayerId()));
    }

    /**
     * Returns a map of valid marker placement actions for the player on the given board.
     * If marker placement is not allowed, evaluates the next policy in sequence.
     *
     * @param board  the board state
     * @param player the player
     * @return a map of valid marker placement actions
     */
    @Override
    public Map<Integer, List<Action>> validActions(Board board, Player player) {
        // Check if game rules satisfy state
        if (isAllowed(board, player)) {
            // Initialise valid actions hashmap to be returned to the UI
            HashMap<Integer, List<Action>> validActions = new HashMap<>();
            // Gets a reference to all the positions on the board that are empty
            List<Position> emptyPositions = board.getPositionsOfPlayer(null);
            // Creates an action command which connects players off marker position to empty positions on board
            validActions.put(player.getMarkerPosition(), new ArrayList<>());
            for (Position futurePosition : emptyPositions) {
                ActionPlace actionPlace = new ActionPlace(futurePosition);
                validActions.get(player.getMarkerPosition()).add(actionPlace);
            }
            return validActions;
        }
        else {
            // If phase isn't valid, evaluate the next policy in sequence
            return PolicyFactory.getPolicy("jump").validActions(board, player);
        }
    }

}


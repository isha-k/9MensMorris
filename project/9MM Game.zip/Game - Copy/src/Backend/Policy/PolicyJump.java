package Backend.Policy;

import Backend.Action.ActionMove;
import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Board.Position;
import Backend.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PolicyJump evaluates if the next move for the player is a jump move based on game rules and returns
 * all the available positions the player can elicit.
 * */
public class PolicyJump extends Policy {

    /**
     * Checks if the given board state allows the player to perform jump moves.
     *
     * @param board  the board state
     * @param player the player
     * @return true if jump moves are allowed, false otherwise
     */
    @Override
    public boolean isAllowed(Board board, Player player){
        return board.getPositions().stream().filter(x -> x.isPlayer(player.getId())).toList().size() == 3;
    }

    /**
     * Returns a map of valid jump actions for the player on the given board.
     * If jump moves are not allowed, evaluates the next policy in sequence.
     *
     * @param board  the board state
     * @param player the player
     * @return a map of valid jump actions
     */
    @Override
    public Map<Integer, List<Action>> validActions(Board board, Player player) {
        //Check if game rules satisfy state
        if (isAllowed(board, player)) {
            //initialise valid actions hashmap to be returned to the UI
            HashMap<Integer, List<Action>> validActions = new HashMap<>();
            //gets a reference to all the positions on the board that belongs to player
            List<Position> playerPositions = board.getPositionsOfPlayer(player.getId());
            //Creates an action command which connects every player position to empty positions on board
            for (Position currentPosition: playerPositions){
                for (Position futurePosition : board.getPositionsOfPlayer(null)) {
                    Action jumpAction = new ActionMove(currentPosition,futurePosition);
                    validActions.computeIfAbsent(currentPosition.getId(), key -> new ArrayList<>())
                            .add(jumpAction);
                }
            }
            return validActions;
        }
        else {
            //If phase isn't valid, evaluate the next policy in sequence
            return PolicyFactory.getPolicy("slide").validActions(board, player);
        }
    }

}


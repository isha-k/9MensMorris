package Backend.Policy;

import Backend.Action.ActionMove;
import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Board.Position;
import Backend.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PolicySlide evaluates if the next move for the player is a slide move based on game rules and returns
 * all the available positions the player can elicit.
 * */
public class PolicySlide extends Policy {

    /**
     * Checks if the given board state allows the player to perform slide moves.
     *
     * @param board  the board state
     * @param player the player
     * @return always true
     */
    @Override
    public boolean isAllowed(Board board, Player player) { return true; }


    /**
     * Returns a map of valid slide actions for the player on the given board.
     *
     * @param board  the board state
     * @param player the player
     * @return a map of valid slide actions
     */
    @Override
    public Map<Integer, List<Action>> validActions(Board board, Player player) {
        // Check if game rules satisfy state
        if (isAllowed(board, player)) {
            // initialise valid actions hashmap to be returned to the UI
            Map<Integer, List<Action>> validActions = new HashMap<>();
            // gets a reference to all the positions on the board that are player markers
            List<Position> playerPositions = board.getPositionsOfPlayer(player.getId());
            // Creates an action command which connects players marker to empty positions on board neighbouring player markers
            for (Position startPosition: playerPositions) {
                for (Position neighboringPosition: startPosition.getNeighbours()) {
                    if (neighboringPosition.isPlayer(null)) {
                        Action slideAction = new ActionMove(startPosition,neighboringPosition);
                        validActions.computeIfAbsent(startPosition.getId(), key -> new ArrayList<>())
                                .add(slideAction);
                    }
                }
            }
            if (validActions.values().stream().allMatch(x -> x.isEmpty())){return new HashMap<>();};
            return validActions;
        }
        // Return no actions if this rule doesn't satisfy.
        return new HashMap<>();
    }

}


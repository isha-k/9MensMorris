package Backend.Policy;

import Backend.Action.ActionRemove;
import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Board.Position;
import Backend.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * PolicyRemove evaluates if the next move for the player is a remove move based on game rules and returns
 * all the available positions the player can elicit.
 * */

public class PolicyRemove extends Policy {

    /**
     * Checks if the given board state allows the player to perform remove moves.
     *
     * @param board  the board state
     * @param player the player
     * @return true if remove moves are allowed, false otherwise
     */
    @Override
    public boolean isAllowed(Board board, Player player){
        // create a set to store markers which are in a mill
        HashSet<Position> milledMarkers = new HashSet<>();
        // obtain the last position which has changed from the game.
        Optional<Position> lastPosition = Optional.ofNullable(board.getLastPosition());
        if (lastPosition.isPresent()){
            //detect all the markers which are in a mill if last position is the middle marker in the mill
            milledMarkers.addAll(lastPosition.get().detectMill());
            //detect all the markers which are in a mill if last position's neighbours is the middle marker in the mill
            lastPosition.get().getNeighbours().forEach(x -> milledMarkers.addAll(x.detectMill()));};
        //return a boolean to dictate if milled markers contain the last position
        return milledMarkers.contains(board.getLastPosition()) && lastPosition.get().getPlayerId() == player.getId();

    }

    /**
     * Returns a map of valid remove actions for the player on the given board.
     * If remove moves are not allowed, evaluates the next policy in sequence.
     *
     * @param board  the board state
     * @param player the player
     * @return a map of valid remove actions
     */
    @Override
    public Map<Integer, List<Action>> validActions(Board board, Player player) {
        // Check if game rules satisfy state
        if (isAllowed(board, player)) {
            // initialise valid actions hashmap to be returned to the UI
            HashMap<Integer, List<Action>> validActions = new HashMap<>();
            Map<Integer, List<Position>> partitionedMap = board.getPositions().stream()
                    //filter positions which belong to the last player and is a empty position (only opponent markers)
                    .filter(position -> (! position.isPlayer(null)) && (! position.isPlayer(board.getLastPosition().getPlayerId())))
                    //partition positions by playerId
                    .collect(Collectors.groupingBy(position -> position.getPlayerId()));
            //create a new list which will store all the markers that can be moves.
            List<Position> markersForMoves = new ArrayList<>();
            //iterate through each opponent and their positions
            partitionedMap.forEach((opponent, positions) -> {
                // create a set to store markers which are in a mill
                Set<Position> milledMoves = new HashSet<>();
                //find all positions which are milled with all opponent positions neighbours
                positions.forEach(position -> position.getNeighbours().forEach(key -> milledMoves.addAll(key.detectMill())));
                //add these positions to moves if they are not milled and is a opponent marker
                markersForMoves.addAll(positions.stream().filter(x -> (! milledMoves.contains(x)) && (x.isPlayer(opponent))).toList());
                //if all positions are in a mill
                if (markersForMoves.size() <= 0) {
                    //add all positions as movable markers
                    markersForMoves.addAll(positions);
                }
            });
            // create an Action connecting marker with the associated removal action
            markersForMoves.forEach(marker -> {
                ActionRemove actionRemove = new ActionRemove(marker);
                validActions.computeIfAbsent(marker.getId(), key -> new ArrayList<>()).add(actionRemove);}
            );

            return validActions;

        } else {
            // If phase isn't valid, evaluate the next policy in sequence
            return new HashMap<>();
        }
    }

}

package Backend.Policy;

import java.util.HashMap;
import java.util.Map;

/**
 * The PolicyFactory class is a factory class to product different policy classes based on a key.
 * It involves a singleton pattern, where existing policies are stored in a hashmap. If a policy matching a key
 * is already present, the method returns this policy, instead of instantiating a new policy. 
 */
public class PolicyFactory {

    /**
     * A Hashmap storing a key to each policy of the game;
     */
    private static Map<String, Policy> policyMap = new HashMap<>();

    /**
     * Method for getting a policy sequentially in the series; first of which is PolicyRemove.
     * @return the policy requested
     */
    public static Policy getPreActionPolicy() { return PolicyFactory.getPolicy("remove"); }

    /**
     * Retrieves the post-action policy.
     * @return The post-action policy.
     */
    public static Policy getPostActionPolicy() { return PolicyFactory.getPolicy("place"); }

    /**
     * Method for getting based on a key; and if the policy hasn't been created yet, generates the policy.
     * @param prompt key for the policy
     * @return the policy requested
     */
    protected static Policy getPolicy(String prompt) {
        return policyMap.computeIfAbsent(prompt, (x) -> {
            Policy policy = switch (prompt.toLowerCase()) {
                case "jump" -> new PolicyJump();
                case "place" -> new PolicyPlace();
                case "remove" -> new PolicyRemove();
                case "slide" -> new PolicySlide();
                default -> throw new IllegalStateException("Unexpected value: " + prompt);
            };
            return policy;
        });
    }

}

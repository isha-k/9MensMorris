package Backend.Policy;

import Backend.Action.Action;
import Backend.Board.Board;
import Backend.Player;

import java.util.List;
import java.util.Map;

/**
 * The Policy abstract class is the condition checker for types of available moves given the current board and player turn.
 */
public abstract class Policy {

    /** Method that checks whether the logic for the particular action is accurate
     * @param board a representation of the game's game board
     * @param player the current player
     * @return whether game rules a valid for the game to elicit a particular action
     */
    public abstract boolean isAllowed(Board board, Player player);

    /** Method that returns a list of valid movements for the player depending on the phase of the game
     * @param board a representation of the game's game board
     * @param player the current player
     * @return Returns a list of valid movements for the player depending on the phase of the game
     */
    public abstract Map<Integer, List<Action>> validActions(Board board, Player player);

}

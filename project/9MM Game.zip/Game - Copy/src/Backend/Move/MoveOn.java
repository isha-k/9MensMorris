package Backend.Move;

import Backend.Board.Position;
import Backend.Player;

/**
 * The MoveOn class represents a move on the board where the player places a marker on the board to a specific position.
 */
public class MoveOn {

    /**
     * Constructs a MoveOn object with the specified position and player.
     * The position's player ID is set to the player's ID, and the player's offset is decremented.
     *
     * @param position the position to move on to
     * @param player   the player performing the action
     */
    public MoveOn(Position position, Player player) {
        position.setPlayerId(player.getId());
        player.decrementOffset();
    }

}


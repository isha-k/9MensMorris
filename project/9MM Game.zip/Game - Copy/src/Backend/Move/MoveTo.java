package Backend.Move;

import Backend.Board.Position;
import Backend.Player;

/**
 * The MoveTo class represents a move on the board where the player moves a marker from one current position to a different, future position.
 */
public class MoveTo {

    /**
     * Constructs a MoveTo object with the specified current position, future position, and player.
     * The current position's player ID is set to null, the future position's player ID is set to the player's ID,
     * and the future position's mill is detected.
     *
     * @param currentPosition the current position
     * @param futurePosition  the future position to move to
     * @param player          the player performing the action
     */
    public MoveTo(Position currentPosition, Position futurePosition, Player player) {
        currentPosition.setPlayerId(null);
        futurePosition.setPlayerId(player.getId());
        futurePosition.detectMill();
    }

}

package Backend.Move;

import Backend.Board.Position;
import Backend.Player;

/**
 * The MoveOff class represents a move on the board where the player removes a marker from the current position.
 */
public class MoveOff {

    /**
     * Constructs a MoveOff object with the specified position and player.
     * The position's player ID is set to null, and the player's score is incremented.
     *
     * @param position the position to move off from
     * @param player   the player performing the action
     */
    public MoveOff(Position position, Player player) {
        position.setPlayerId(null);
        player.incrementPlayerScore();
        System.out.println("PLAYER SCORE : "+player.getPlayerScore());
    }

}

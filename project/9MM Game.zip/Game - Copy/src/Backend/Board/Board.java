package Backend.Board;

import java.util.*;

/**
 * The Board class is the virtual representation of the actual Nine Men's Morris game's game board.
 */
public class Board {

    /** The data structure that captures the virtual representation of all playable positions on the board. */
    private List<Position> positions = new ArrayList<>();

    /** The last position changed by either player */
    private Position lastPosition;

    /**
     * Constructs a Board object and initializes it with the default configuration.
     */
    public Board(int gridSize, List<Integer> positions, Map<Integer, List<Integer>> neighbours) {
        for (int position : positions) {
            this.addPosition(gridSize, position);
        }
        for (int parent : neighbours.keySet()) {
            for (int neighbour : neighbours.get(parent)) {
                this.addNeighbour(parent, neighbour);
            }
        }
    }

    /**
     * Returns a list of positions on the board.
     *
     * @return a list of positions on the board
     */
    public List<Position> getPositions() { return this.positions; }

    /**
     * Returns the last position on the board.
     *
     * @return the last position on the board
     */
    public Position getLastPosition() { return this.lastPosition; }

    /**
     * Sets the last position on the board.
     *
     * @param position the last position to set
     */
    public void setLastPosition(Position position) { this.lastPosition = position; }

    /** Method that filters the game board for positions that belong to a specified player
     * @param playerId the player index for which we are filtering for
     * @return a list of positions that belongs to the specified player
     * */
    public List<Position> getPositionsOfPlayer(Integer playerId){
        return this.positions.stream().filter(value -> value.isPlayer(playerId)).toList();
    }

    /** Method for adding a new Position to the game board, while incrementing the total amount of positions present.
     */
    private void addPosition(int gridSize,int id) { this.positions.add(new Position(gridSize,id)); }

    /** Method for making a bidirectional connection between one position and another position
     * @param neighbour1 a position that connects up the other position
     * @param neighbour2 the other position that connects up a position
     */
    private void addNeighbour(int neighbour1, int neighbour2) {
        Position neighbour1position = this.positions.stream()
                .filter(position -> position.getId() == neighbour1)
                .findFirst().get();
        Position neighbour2position = this.positions.stream()
                .filter(position -> position.getId() == neighbour2)
                .findFirst().get();
        neighbour1position.addNeighbor(neighbour2position);
        neighbour2position.addNeighbor(neighbour1position);
    }

}



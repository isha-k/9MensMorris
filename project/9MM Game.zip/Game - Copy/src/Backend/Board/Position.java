package Backend.Board;

import java.util.*;

public class Position {

    /** The unique identifier of a position */
    private int id;

    /** The x-coordinate of the position on the game board */
    private int x;

    /** The y-coordinate of the position on the game board */
    private int y;

    /** The player index to which the position currently belongs to, or null if it is currently empty */
    private Integer playerId = null;

    /** The data structure for storing a position's neighbours, keyed by positional slope */
    private HashMap<Double, Set<Position>> neighbors = new HashMap<>();

    /**
     * Constructs a Position object with the specified ID, X and Y coordinates.
     *
     * @param id the unique identifier of the position
     */
    public Position(int gridSize, int id) {
        this.id = id;
        this.x = (id / gridSize) % gridSize;
        this.y = id % gridSize;
    }

    /**
     * Returns the ID of the position.
     *
     * @return the ID of the position
     */
    public int getId() { return this.id; }

    /**
     * Returns the ID of the player associated with the position.
     *
     * @return the ID of the player associated with the position
     */
    public Integer getPlayerId() { return this.playerId; }

    /**
     * Returns the X coordinate of the position.
     *
     * @return the X coordinate of the position
     */
    public int getX() { return x; }

    /**
     * Returns the Y coordinate of the position.
     *
     * @return the Y coordinate of the position
     */
    public int getY() { return y; }

    /**
     * Returns the neighbors of the position.
     *
     * @return the neighbors of the position
     */
    public ArrayList<Position> getNeighbours(){
        ArrayList<Position> singleList = new ArrayList<>();
        neighbors.values().forEach(singleList::addAll);
        return singleList;
    }

    /**
     * Sets the ID of the player associated with the position.
     *
     * @param playerId the ID of the player to set
     */
    public void setPlayerId(Integer playerId) { this.playerId = playerId; }

    /** Method to determine whether the position is in a certain state
     * @param playerId the player index
     * @return a boolean representing whether the position has a certain state.
     * */
    public boolean isPlayer(Integer playerId) { return this.playerId == playerId; }

    /** Method that processes adding a neighbour by corresponding it to the slope
     * @param position the neighbouring position to be added
     * */
    public void addNeighbor(Position position) {
        double direction;
        if (this.x - position.getX() == 0) { // handle vertical line case
            direction = Double.POSITIVE_INFINITY;
        } else {
            direction = (this.y - position.getY()) / (this.x - position.getX());
        }
        neighbors.computeIfAbsent(direction, key -> new HashSet<>()).add(position);
    }

    /** Method that finds all markers neighbouring to the current one that are in a mill
     * @returns list of markers neighbouring the position that are in a mill
     */
    public List<Position> detectMill() {
        ArrayList<Position> milledMarkers = new ArrayList<>();
        if (this.playerId != null) {
            for (Double direction : neighbors.keySet()) {
                if (detectMillforDirection(neighbors.get(direction))) {
                    milledMarkers.addAll(neighbors.get(direction));
                }
            }
            if (! milledMarkers.isEmpty()) {
                milledMarkers.add(this);
            }
        }
        return milledMarkers;
    }

    /** Method which helps in mill detection by detecting only markers in a specified direction
     * @param position list of neighbours of the position that are in the same position to the position
     * @return a boolean of whether these neighbours are in the same direction as the marker and is in a mill
     **/
    private boolean detectMillforDirection(Set<Position> position) {
        return (position.size() > 1) && (position.stream().allMatch(pos -> pos.playerId == this.playerId));
    }

}















